import { eq, and } from 'drizzle-orm';
import { db } from './db';
import {
  users, stocks, portfolioItems, transactions, moduleCompletions,
  type User, type InsertUser, type Stock, type InsertStock,
  type PortfolioItem, type InsertPortfolioItem, type Transaction,
  type InsertTransaction, type ModuleCompletion, type InsertModuleCompletion,
  type PortfolioItemWithStock, type TransactionWithStock, type UserWithPortfolio
} from "@shared/schema";
import { IStorage } from './storage';

export class PostgresStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const results = await db.select().from(users).where(eq(users.id, id));
    return results[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const results = await db.select().from(users).where(eq(users.username, username));
    return results[0];
  }

  async getUserByLearnWorldsId(learnWorldsId: string): Promise<User | undefined> {
    const results = await db.select().from(users).where(eq(users.learnWorldsId, learnWorldsId));
    return results[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const results = await db.insert(users).values(user).returning();
    return results[0];
  }

  async updateUserBalance(userId: number, newBalance: number): Promise<User | undefined> {
    const results = await db
      .update(users)
      .set({ balance: newBalance.toString() })
      .where(eq(users.id, userId))
      .returning();
    return results[0];
  }

  // Stock methods
  async getAllStocks(): Promise<Stock[]> {
    return await db.select().from(stocks);
  }

  async getActiveStocks(): Promise<Stock[]> {
    return await db.select().from(stocks).where(eq(stocks.isActive, true));
  }

  async getStock(id: number): Promise<Stock | undefined> {
    const results = await db.select().from(stocks).where(eq(stocks.id, id));
    return results[0];
  }

  async getStockBySymbol(symbol: string): Promise<Stock | undefined> {
    const results = await db.select().from(stocks).where(eq(stocks.symbol, symbol));
    return results[0];
  }

  async createStock(stock: InsertStock): Promise<Stock> {
    const results = await db.insert(stocks).values(stock).returning();
    return results[0];
  }

  async updateStock(id: number, stock: Partial<InsertStock>): Promise<Stock | undefined> {
    const results = await db
      .update(stocks)
      .set(stock)
      .where(eq(stocks.id, id))
      .returning();
    return results[0];
  }

  async deleteStock(id: number): Promise<boolean> {
    const results = await db
      .delete(stocks)
      .where(eq(stocks.id, id))
      .returning();
    return results.length > 0;
  }

  // Portfolio methods
  async getPortfolioItems(userId: number): Promise<PortfolioItemWithStock[]> {
    const items = await db
      .select()
      .from(portfolioItems)
      .where(eq(portfolioItems.userId, userId));

    return Promise.all(
      items.map(async (item) => {
        const stock = await this.getStock(item.stockId);
        if (!stock) throw new Error(`Stock not found for id: ${item.stockId}`);

        const value = Number(item.shares) * Number(stock.price);
        const cost = Number(item.shares) * Number(item.avgPrice);
        const gainLoss = value - cost;
        const gainLossPercentage = (gainLoss / cost) * 100;

        return {
          ...item,
          stock,
          value,
          gainLoss,
          gainLossPercentage,
        };
      })
    );
  }

  async getPortfolioItem(userId: number, stockId: number): Promise<PortfolioItemWithStock | undefined> {
    const results = await db
      .select()
      .from(portfolioItems)
      .where(
        and(
          eq(portfolioItems.userId, userId),
          eq(portfolioItems.stockId, stockId)
        )
      );

    const item = results[0];
    if (!item) return undefined;

    const stock = await this.getStock(item.stockId);
    if (!stock) throw new Error(`Stock not found for id: ${item.stockId}`);

    const value = Number(item.shares) * Number(stock.price);
    const cost = Number(item.shares) * Number(item.avgPrice);
    const gainLoss = value - cost;
    const gainLossPercentage = (gainLoss / cost) * 100;

    return {
      ...item,
      stock,
      value,
      gainLoss,
      gainLossPercentage,
    };
  }

  async createPortfolioItem(item: InsertPortfolioItem): Promise<PortfolioItem> {
    const results = await db.insert(portfolioItems).values(item).returning();
    return results[0];
  }

  async updatePortfolioItem(id: number, item: Partial<InsertPortfolioItem>): Promise<PortfolioItem | undefined> {
    const results = await db
      .update(portfolioItems)
      .set(item)
      .where(eq(portfolioItems.id, id))
      .returning();
    return results[0];
  }

  async deletePortfolioItem(id: number): Promise<boolean> {
    const results = await db
      .delete(portfolioItems)
      .where(eq(portfolioItems.id, id))
      .returning();
    return results.length > 0;
  }

  // Transaction methods
  async getUserTransactions(userId: number): Promise<TransactionWithStock[]> {
    const userTransactions = await db
      .select()
      .from(transactions)
      .where(eq(transactions.userId, userId));

    return Promise.all(
      userTransactions.map(async (transaction) => {
        const stock = await this.getStock(transaction.stockId);
        if (!stock) throw new Error(`Stock not found for id: ${transaction.stockId}`);

        return {
          ...transaction,
          stock,
        };
      })
    );
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const results = await db.insert(transactions).values(transaction).returning();
    return results[0];
  }

  // Module completion methods
  async getModuleCompletions(userId: number): Promise<ModuleCompletion[]> {
    return await db
      .select()
      .from(moduleCompletions)
      .where(eq(moduleCompletions.userId, userId));
  }

  async createModuleCompletion(completion: InsertModuleCompletion): Promise<ModuleCompletion> {
    const results = await db.insert(moduleCompletions).values(completion).returning();
    return results[0];
  }

  async getCompletedModules(userId: number): Promise<string[]> {
    const completions = await this.getModuleCompletions(userId);
    return completions.map(completion => completion.moduleId);
  }

  // Dashboard data
  async getUserPortfolioSummary(userId: number): Promise<UserWithPortfolio | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;

    const portfolioItems = await this.getPortfolioItems(userId);
    
    const totalValue = portfolioItems.reduce((total, item) => total + item.value, 0);
    const totalCost = portfolioItems.reduce((total, item) => total + (Number(item.shares) * Number(item.avgPrice)), 0);
    const totalGain = totalValue - totalCost;

    return {
      ...user,
      portfolioItems,
      totalValue,
      totalGain,
    };
  }

  // Initialize with sample stocks
  async initializeStocks() {
    const existingStocks = await this.getAllStocks();
    if (existingStocks.length > 0) {
      return; // Already initialized
    }

    const sampleStocks: InsertStock[] = [
      { symbol: "AAPL", name: "Apple Inc.", price: "182.63", previousPrice: "178.33", sector: "Technology", marketCap: "2.8T", isActive: true },
      { symbol: "MSFT", name: "Microsoft Corp.", price: "290.17", previousPrice: "285.02", sector: "Technology", marketCap: "2.1T", isActive: true },
      { symbol: "GOOGL", name: "Alphabet Inc.", price: "118.33", previousPrice: "119.04", sector: "Technology", marketCap: "1.5T", isActive: true },
      { symbol: "AMZN", name: "Amazon.com Inc.", price: "113.50", previousPrice: "110.04", sector: "Consumer Cyclical", marketCap: "1.2T", isActive: true },
      { symbol: "TSLA", name: "Tesla Inc.", price: "725.60", previousPrice: "741.20", sector: "Consumer Cyclical", marketCap: "750B", isActive: true },
      { symbol: "META", name: "Meta Platforms Inc.", price: "276.38", previousPrice: "293.46", sector: "Technology", marketCap: "695B", isActive: true },
      { symbol: "NFLX", name: "Netflix Inc.", price: "421.10", previousPrice: "410.35", sector: "Communication Services", marketCap: "185B", isActive: true },
    ];

    for (const stock of sampleStocks) {
      await this.createStock(stock);
    }
  }
}