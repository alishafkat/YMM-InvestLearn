import { storage } from "./storage";

async function initializeAdmin() {
  try {
    // Check if admin user already exists
    const existingAdmin = await storage.getUserByUsername("admin");
    
    if (existingAdmin) {
      console.log("Admin user already exists");
      return;
    }
    
    // Create admin user
    const admin = await storage.createUser({
      username: "admin",
      password: "admin123",
      learnWorldsId: null,
      name: "Admin User",
      email: "admin@example.com",
      avatar: null,
      isAdmin: true,
      balance: "50000"
    });
    
    console.log("Admin user created successfully:", admin.username);
    
    // Create a regular user
    const user = await storage.createUser({
      username: "user",
      password: "user123",
      learnWorldsId: null,
      name: "Regular User",
      email: "user@example.com",
      avatar: null,
      isAdmin: false,
      balance: "10000"
    });
    
    console.log("Regular user created successfully:", user.username);
    
  } catch (error) {
    console.error("Error initializing admin user:", error);
  }
}

// Call the function
initializeAdmin();