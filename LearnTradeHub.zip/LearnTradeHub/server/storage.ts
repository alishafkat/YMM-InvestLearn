import {
  users, stocks, portfolioItems, transactions, moduleCompletions,
  type User, type InsertUser, type Stock, type InsertStock,
  type PortfolioItem, type InsertPortfolioItem, type Transaction,
  type InsertTransaction, type ModuleCompletion, type InsertModuleCompletion,
  type PortfolioItemWithStock, type TransactionWithStock, type UserWithPortfolio
} from "@shared/schema";

// Storage interface
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByLearnWorldsId(learnWorldsId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserBalance(userId: number, newBalance: number): Promise<User | undefined>;
  
  // Stock methods
  getAllStocks(): Promise<Stock[]>;
  getActiveStocks(): Promise<Stock[]>;
  getStock(id: number): Promise<Stock | undefined>;
  getStockBySymbol(symbol: string): Promise<Stock | undefined>;
  createStock(stock: InsertStock): Promise<Stock>;
  updateStock(id: number, stock: Partial<InsertStock>): Promise<Stock | undefined>;
  deleteStock(id: number): Promise<boolean>;

  // Portfolio methods
  getPortfolioItems(userId: number): Promise<PortfolioItemWithStock[]>;
  getPortfolioItem(userId: number, stockId: number): Promise<PortfolioItemWithStock | undefined>;
  createPortfolioItem(item: InsertPortfolioItem): Promise<PortfolioItem>;
  updatePortfolioItem(id: number, item: Partial<InsertPortfolioItem>): Promise<PortfolioItem | undefined>;
  deletePortfolioItem(id: number): Promise<boolean>;

  // Transaction methods
  getUserTransactions(userId: number): Promise<TransactionWithStock[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;

  // Module completion methods
  getModuleCompletions(userId: number): Promise<ModuleCompletion[]>;
  createModuleCompletion(completion: InsertModuleCompletion): Promise<ModuleCompletion>;
  getCompletedModules(userId: number): Promise<string[]>;

  // Dashboard data
  getUserPortfolioSummary(userId: number): Promise<UserWithPortfolio | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private stocks: Map<number, Stock>;
  private portfolioItems: Map<number, PortfolioItem>;
  private transactions: Map<number, Transaction>;
  private moduleCompletions: Map<number, ModuleCompletion>;
  
  private userId: number;
  private stockId: number;
  private portfolioItemId: number;
  private transactionId: number;
  private moduleCompletionId: number;

  constructor() {
    this.users = new Map();
    this.stocks = new Map();
    this.portfolioItems = new Map();
    this.transactions = new Map();
    this.moduleCompletions = new Map();
    
    this.userId = 1;
    this.stockId = 1;
    this.portfolioItemId = 1;
    this.transactionId = 1;
    this.moduleCompletionId = 1;

    // Initialize with sample stocks
    this.initializeStocks();
  }

  // Initialize with some default stocks
  private initializeStocks() {
    const sampleStocks: InsertStock[] = [
      { symbol: "AAPL", name: "Apple Inc.", price: "182.63", previousPrice: "178.33", sector: "Technology", marketCap: "2.8T", isActive: true },
      { symbol: "MSFT", name: "Microsoft Corp.", price: "290.17", previousPrice: "285.02", sector: "Technology", marketCap: "2.1T", isActive: true },
      { symbol: "GOOGL", name: "Alphabet Inc.", price: "118.33", previousPrice: "119.04", sector: "Technology", marketCap: "1.5T", isActive: true },
      { symbol: "AMZN", name: "Amazon.com Inc.", price: "113.50", previousPrice: "110.04", sector: "Consumer Cyclical", marketCap: "1.2T", isActive: true },
      { symbol: "TSLA", name: "Tesla Inc.", price: "725.60", previousPrice: "741.20", sector: "Consumer Cyclical", marketCap: "750B", isActive: true },
      { symbol: "META", name: "Meta Platforms Inc.", price: "276.38", previousPrice: "293.46", sector: "Technology", marketCap: "695B", isActive: true },
      { symbol: "NFLX", name: "Netflix Inc.", price: "421.10", previousPrice: "410.35", sector: "Communication Services", marketCap: "185B", isActive: true },
    ];

    sampleStocks.forEach(stock => this.createStock(stock));
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async getUserByLearnWorldsId(learnWorldsId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.learnWorldsId === learnWorldsId
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { 
      ...insertUser, 
      id, 
      balance: insertUser.balance || "10000",
      learnWorldsId: insertUser.learnWorldsId || null,
      name: insertUser.name || null,
      email: insertUser.email || null,
      avatar: insertUser.avatar || null,
      isAdmin: insertUser.isAdmin || false
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserBalance(userId: number, newBalance: number): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;
    
    const updatedUser = { ...user, balance: newBalance.toString() };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  // Stock methods
  async getAllStocks(): Promise<Stock[]> {
    return Array.from(this.stocks.values());
  }

  async getActiveStocks(): Promise<Stock[]> {
    return Array.from(this.stocks.values()).filter(stock => stock.isActive);
  }

  async getStock(id: number): Promise<Stock | undefined> {
    return this.stocks.get(id);
  }

  async getStockBySymbol(symbol: string): Promise<Stock | undefined> {
    return Array.from(this.stocks.values()).find(
      (stock) => stock.symbol === symbol
    );
  }

  async createStock(insertStock: InsertStock): Promise<Stock> {
    const id = this.stockId++;
    const createdAt = new Date();
    const stock: Stock = { 
      ...insertStock, 
      id, 
      createdAt, 
      previousPrice: insertStock.previousPrice || null,
      marketCap: insertStock.marketCap || null,
      isActive: insertStock.isActive !== undefined ? insertStock.isActive : true
    };
    this.stocks.set(id, stock);
    return stock;
  }

  async updateStock(id: number, stockUpdate: Partial<InsertStock>): Promise<Stock | undefined> {
    const stock = this.stocks.get(id);
    if (!stock) return undefined;

    const updatedStock = { ...stock, ...stockUpdate };
    this.stocks.set(id, updatedStock);
    return updatedStock;
  }

  async deleteStock(id: number): Promise<boolean> {
    return this.stocks.delete(id);
  }

  // Portfolio methods
  async getPortfolioItems(userId: number): Promise<PortfolioItemWithStock[]> {
    const items = Array.from(this.portfolioItems.values()).filter(
      (item) => item.userId === userId
    );

    return Promise.all(
      items.map(async (item) => {
        const stock = await this.getStock(item.stockId);
        if (!stock) throw new Error(`Stock not found for id: ${item.stockId}`);

        const value = Number(item.shares) * Number(stock.price);
        const cost = Number(item.shares) * Number(item.avgPrice);
        const gainLoss = value - cost;
        const gainLossPercentage = (gainLoss / cost) * 100;

        return {
          ...item,
          stock,
          value,
          gainLoss,
          gainLossPercentage,
        };
      })
    );
  }

  async getPortfolioItem(userId: number, stockId: number): Promise<PortfolioItemWithStock | undefined> {
    const item = Array.from(this.portfolioItems.values()).find(
      (item) => item.userId === userId && item.stockId === stockId
    );

    if (!item) return undefined;

    const stock = await this.getStock(item.stockId);
    if (!stock) throw new Error(`Stock not found for id: ${item.stockId}`);

    const value = Number(item.shares) * Number(stock.price);
    const cost = Number(item.shares) * Number(item.avgPrice);
    const gainLoss = value - cost;
    const gainLossPercentage = (gainLoss / cost) * 100;

    return {
      ...item,
      stock,
      value,
      gainLoss,
      gainLossPercentage,
    };
  }

  async createPortfolioItem(insertItem: InsertPortfolioItem): Promise<PortfolioItem> {
    const id = this.portfolioItemId++;
    const createdAt = new Date();
    const item: PortfolioItem = { ...insertItem, id, createdAt };
    this.portfolioItems.set(id, item);
    return item;
  }

  async updatePortfolioItem(id: number, itemUpdate: Partial<InsertPortfolioItem>): Promise<PortfolioItem | undefined> {
    const item = this.portfolioItems.get(id);
    if (!item) return undefined;

    const updatedItem = { ...item, ...itemUpdate };
    this.portfolioItems.set(id, updatedItem);
    return updatedItem;
  }

  async deletePortfolioItem(id: number): Promise<boolean> {
    return this.portfolioItems.delete(id);
  }

  // Transaction methods
  async getUserTransactions(userId: number): Promise<TransactionWithStock[]> {
    const userTransactions = Array.from(this.transactions.values()).filter(
      (transaction) => transaction.userId === userId
    );

    return Promise.all(
      userTransactions.map(async (transaction) => {
        const stock = await this.getStock(transaction.stockId);
        if (!stock) throw new Error(`Stock not found for id: ${transaction.stockId}`);

        return {
          ...transaction,
          stock,
        };
      })
    );
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = this.transactionId++;
    const createdAt = new Date();
    const transaction: Transaction = { ...insertTransaction, id, createdAt };
    this.transactions.set(id, transaction);
    return transaction;
  }

  // Module completion methods
  async getModuleCompletions(userId: number): Promise<ModuleCompletion[]> {
    return Array.from(this.moduleCompletions.values()).filter(
      (completion) => completion.userId === userId
    );
  }

  async createModuleCompletion(insertCompletion: InsertModuleCompletion): Promise<ModuleCompletion> {
    const id = this.moduleCompletionId++;
    const completedAt = new Date();
    const completion: ModuleCompletion = { 
      ...insertCompletion, 
      id, 
      completedAt,
      rewardAmount: insertCompletion.rewardAmount || null
    };
    this.moduleCompletions.set(id, completion);
    return completion;
  }

  async getCompletedModules(userId: number): Promise<string[]> {
    const completions = await this.getModuleCompletions(userId);
    return completions.map(completion => completion.moduleId);
  }

  // Dashboard data
  async getUserPortfolioSummary(userId: number): Promise<UserWithPortfolio | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;

    const portfolioItems = await this.getPortfolioItems(userId);
    
    const totalValue = portfolioItems.reduce((total, item) => total + item.value, 0);
    const totalCost = portfolioItems.reduce((total, item) => total + (Number(item.shares) * Number(item.avgPrice)), 0);
    const totalGain = totalValue - totalCost;

    return {
      ...user,
      portfolioItems,
      totalValue,
      totalGain,
    };
  }
}

import { PostgresStorage } from './db-storage';

// Initialize the appropriate storage based on environment
const postgresStorage = new PostgresStorage();

// Initialize the database with sample data if needed
postgresStorage.initializeStocks().catch(err => {
  console.error('Error initializing database:', err);
});

export const storage = postgresStorage;
