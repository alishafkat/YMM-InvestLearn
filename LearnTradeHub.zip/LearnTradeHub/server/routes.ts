import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { WebSocketServer, WebSocket } from "ws";
import { z } from "zod";
import session from "express-session";
import {
  insertUserSchema,
  insertStockSchema,
  insertPortfolioItemSchema,
  insertTransactionSchema,
  insertModuleCompletionSchema
} from "@shared/schema";

// Extend express-session types to include userId
declare module "express-session" {
  interface SessionData {
    userId?: number;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Setup WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Track connected clients
  const clients = new Set<WebSocket>();
  
  wss.on('connection', (ws) => {
    clients.add(ws);
    
    ws.send(JSON.stringify({ type: 'connection', message: 'Connected to InvestLearn WebSocket server' }));
    
    ws.on('close', () => {
      clients.delete(ws);
    });
  });
  
  // Helper function to broadcast updates to all connected clients
  const broadcastUpdate = (data: any) => {
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(data));
      }
    });
  };

  // Auth routes
  app.post('/api/auth/login', async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: 'Username and password are required' });
      }
      
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }
      
      // Set the user in the session
      req.session.userId = user.id;
      
      // Return user info without password
      const { password: _, ...userWithoutPassword } = user;
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ message: 'Error during login' });
    }
  });
  
  app.post('/api/auth/learnworlds-login', async (req: Request, res: Response) => {
    try {
      const { learnWorldsId, email, name } = req.body;
      
      if (!learnWorldsId) {
        return res.status(400).json({ message: 'LearnWorlds ID is required' });
      }
      
      let user = await storage.getUserByLearnWorldsId(learnWorldsId);
      
      // If user doesn't exist, create a new one
      if (!user) {
        const username = email || `user_${learnWorldsId}`;
        const password = Math.random().toString(36).slice(-8); // Generate random password
        
        user = await storage.createUser({
          username,
          password,
          learnWorldsId,
          email,
          name,
          balance: 10000,
          isAdmin: false
        });
      }
      
      // Set the user in the session
      req.session.userId = user.id;
      
      // Return user info without password
      const { password: _, ...userWithoutPassword } = user;
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      console.error('LearnWorlds login error:', error);
      res.status(500).json({ message: 'Error during LearnWorlds login' });
    }
  });
  
  app.get('/api/auth/logout', (req: Request, res: Response) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: 'Error during logout' });
      }
      res.status(200).json({ message: 'Logged out successfully' });
    });
  });
  
  app.get('/api/auth/session', async (req: Request, res: Response) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ message: 'Not authenticated' });
      }
      
      const user = await storage.getUser(req.session.userId);
      
      if (!user) {
        return res.status(401).json({ message: 'User not found' });
      }
      
      // Return user info without password
      const { password: _, ...userWithoutPassword } = user;
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      console.error('Session error:', error);
      res.status(500).json({ message: 'Error retrieving session' });
    }
  });
  
  // Middleware to check if user is authenticated
  const isAuthenticated = async (req: Request, res: Response, next: Function) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    next();
  };
  
  // Middleware to check if user is admin
  const isAdmin = async (req: Request, res: Response, next: Function) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    
    const user = await storage.getUser(req.session.userId);
    
    if (!user || !user.isAdmin) {
      return res.status(403).json({ message: 'Not authorized' });
    }
    
    next();
  };
  
  // User routes
  app.get('/api/user/profile', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const user = await storage.getUser(req.session.userId!);
      
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Return user info without password
      const { password: _, ...userWithoutPassword } = user;
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      console.error('Profile error:', error);
      res.status(500).json({ message: 'Error retrieving profile' });
    }
  });
  
  app.post('/api/user/reward', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { moduleId, moduleName, rewardAmount } = req.body;
      
      if (!moduleId || !moduleName || !rewardAmount) {
        return res.status(400).json({ message: 'Module ID, name, and reward amount are required' });
      }
      
      const userId = req.session.userId!;
      
      // Check if the module has already been completed
      const completedModules = await storage.getCompletedModules(userId);
      
      if (completedModules.includes(moduleId)) {
        return res.status(400).json({ message: 'Module already completed' });
      }
      
      // Record module completion
      await storage.createModuleCompletion({
        userId,
        moduleId,
        moduleName,
        rewardAmount
      });
      
      // Update user balance
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      const newBalance = Number(user.balance) + Number(rewardAmount);
      const updatedUser = await storage.updateUserBalance(userId, newBalance);
      
      if (!updatedUser) {
        return res.status(500).json({ message: 'Failed to update balance' });
      }
      
      // Broadcast the update to all clients
      broadcastUpdate({
        type: 'module_completed',
        data: {
          userId,
          moduleId,
          moduleName,
          rewardAmount
        }
      });
      
      // Return user info without password
      const { password: _, ...userWithoutPassword } = updatedUser;
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      console.error('Reward error:', error);
      res.status(500).json({ message: 'Error processing reward' });
    }
  });
  
  // Stock routes
  app.get('/api/stocks', async (req: Request, res: Response) => {
    try {
      const stocks = await storage.getActiveStocks();
      res.status(200).json(stocks);
    } catch (error) {
      console.error('Get stocks error:', error);
      res.status(500).json({ message: 'Error retrieving stocks' });
    }
  });
  
  app.get('/api/stocks/:id', async (req: Request, res: Response) => {
    try {
      const stockId = parseInt(req.params.id);
      
      if (isNaN(stockId)) {
        return res.status(400).json({ message: 'Invalid stock ID' });
      }
      
      const stock = await storage.getStock(stockId);
      
      if (!stock) {
        return res.status(404).json({ message: 'Stock not found' });
      }
      
      res.status(200).json(stock);
    } catch (error) {
      console.error('Get stock error:', error);
      res.status(500).json({ message: 'Error retrieving stock' });
    }
  });
  
  app.post('/api/stocks/buy', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { stockId, shares } = req.body;
      
      if (!stockId || !shares || shares <= 0) {
        return res.status(400).json({ message: 'Stock ID and shares are required' });
      }
      
      const userId = req.session.userId!;
      const user = await storage.getUser(userId);
      const stock = await storage.getStock(stockId);
      
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      if (!stock) {
        return res.status(404).json({ message: 'Stock not found' });
      }
      
      if (!stock.isActive) {
        return res.status(400).json({ message: 'Stock is not active' });
      }
      
      // Calculate total cost
      const totalCost = Number(shares) * Number(stock.price);
      
      // Check if user has enough balance
      if (Number(user.balance) < totalCost) {
        return res.status(400).json({ message: 'Insufficient balance' });
      }
      
      // Update user balance
      const newBalance = Number(user.balance) - totalCost;
      await storage.updateUserBalance(userId, newBalance);
      
      // Check if user already owns this stock
      const existingItem = await storage.getPortfolioItem(userId, stockId);
      
      if (existingItem) {
        // Update existing portfolio item
        const totalShares = Number(existingItem.shares) + Number(shares);
        const totalCostBasis = (Number(existingItem.avgPrice) * Number(existingItem.shares)) + totalCost;
        const newAvgPrice = totalCostBasis / totalShares;
        
        await storage.updatePortfolioItem(existingItem.id, {
          shares: totalShares,
          avgPrice: newAvgPrice
        });
      } else {
        // Create new portfolio item
        await storage.createPortfolioItem({
          userId,
          stockId,
          shares: Number(shares),
          avgPrice: Number(stock.price)
        });
      }
      
      // Record transaction
      const transaction = await storage.createTransaction({
        userId,
        stockId,
        type: 'buy',
        shares: Number(shares),
        price: Number(stock.price),
        total: totalCost
      });
      
      // Broadcast the update to all clients
      broadcastUpdate({
        type: 'transaction',
        data: {
          userId,
          stockId,
          stock: stock.symbol,
          action: 'buy',
          shares,
          price: stock.price,
          total: totalCost
        }
      });
      
      res.status(200).json({
        message: 'Stock purchased successfully',
        transaction
      });
    } catch (error) {
      console.error('Buy stock error:', error);
      res.status(500).json({ message: 'Error purchasing stock' });
    }
  });
  
  app.post('/api/stocks/sell', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { stockId, shares } = req.body;
      
      if (!stockId || !shares || shares <= 0) {
        return res.status(400).json({ message: 'Stock ID and shares are required' });
      }
      
      const userId = req.session.userId!;
      const user = await storage.getUser(userId);
      const stock = await storage.getStock(stockId);
      
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      if (!stock) {
        return res.status(404).json({ message: 'Stock not found' });
      }
      
      // Check if user owns the stock and has enough shares
      const portfolioItem = await storage.getPortfolioItem(userId, stockId);
      
      if (!portfolioItem || Number(portfolioItem.shares) < Number(shares)) {
        return res.status(400).json({ message: 'Insufficient shares' });
      }
      
      // Calculate sale amount
      const saleAmount = Number(shares) * Number(stock.price);
      
      // Update user balance
      const newBalance = Number(user.balance) + saleAmount;
      await storage.updateUserBalance(userId, newBalance);
      
      // Update portfolio item
      const remainingShares = Number(portfolioItem.shares) - Number(shares);
      
      if (remainingShares > 0) {
        // Update with remaining shares
        await storage.updatePortfolioItem(portfolioItem.id, {
          shares: remainingShares
        });
      } else {
        // Remove the portfolio item if no shares left
        await storage.deletePortfolioItem(portfolioItem.id);
      }
      
      // Record transaction
      const transaction = await storage.createTransaction({
        userId,
        stockId,
        type: 'sell',
        shares: Number(shares),
        price: Number(stock.price),
        total: saleAmount
      });
      
      // Broadcast the update to all clients
      broadcastUpdate({
        type: 'transaction',
        data: {
          userId,
          stockId,
          stock: stock.symbol,
          action: 'sell',
          shares,
          price: stock.price,
          total: saleAmount
        }
      });
      
      res.status(200).json({
        message: 'Stock sold successfully',
        transaction
      });
    } catch (error) {
      console.error('Sell stock error:', error);
      res.status(500).json({ message: 'Error selling stock' });
    }
  });
  
  // Portfolio routes
  app.get('/api/portfolio', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = req.session.userId!;
      const portfolioItems = await storage.getPortfolioItems(userId);
      
      res.status(200).json(portfolioItems);
    } catch (error) {
      console.error('Get portfolio error:', error);
      res.status(500).json({ message: 'Error retrieving portfolio' });
    }
  });
  
  app.get('/api/portfolio/summary', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = req.session.userId!;
      const summary = await storage.getUserPortfolioSummary(userId);
      
      if (!summary) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Remove password from response
      const { password: _, ...summaryWithoutPassword } = summary;
      
      res.status(200).json(summaryWithoutPassword);
    } catch (error) {
      console.error('Get portfolio summary error:', error);
      res.status(500).json({ message: 'Error retrieving portfolio summary' });
    }
  });
  
  // Transaction routes
  app.get('/api/transactions', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = req.session.userId!;
      const transactions = await storage.getUserTransactions(userId);
      
      res.status(200).json(transactions);
    } catch (error) {
      console.error('Get transactions error:', error);
      res.status(500).json({ message: 'Error retrieving transactions' });
    }
  });
  
  // Admin routes
  app.get('/api/admin/stocks', isAdmin, async (req: Request, res: Response) => {
    try {
      const stocks = await storage.getAllStocks();
      res.status(200).json(stocks);
    } catch (error) {
      console.error('Admin get stocks error:', error);
      res.status(500).json({ message: 'Error retrieving stocks' });
    }
  });
  
  app.post('/api/admin/stocks', isAdmin, async (req: Request, res: Response) => {
    try {
      // Validate input
      const validationResult = insertStockSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ message: 'Invalid stock data', errors: validationResult.error });
      }
      
      const stock = await storage.createStock(validationResult.data);
      
      // Broadcast the update to all clients
      broadcastUpdate({
        type: 'stock_created',
        data: stock
      });
      
      res.status(201).json(stock);
    } catch (error) {
      console.error('Admin create stock error:', error);
      res.status(500).json({ message: 'Error creating stock' });
    }
  });
  
  app.put('/api/admin/stocks/:id', isAdmin, async (req: Request, res: Response) => {
    try {
      const stockId = parseInt(req.params.id);
      
      if (isNaN(stockId)) {
        return res.status(400).json({ message: 'Invalid stock ID' });
      }
      
      const existingStock = await storage.getStock(stockId);
      
      if (!existingStock) {
        return res.status(404).json({ message: 'Stock not found' });
      }
      
      // Store previous price for change calculation
      if (req.body.price && req.body.price !== existingStock.price) {
        req.body.previousPrice = existingStock.price;
      }
      
      const updatedStock = await storage.updateStock(stockId, req.body);
      
      if (!updatedStock) {
        return res.status(500).json({ message: 'Failed to update stock' });
      }
      
      // Broadcast the update to all clients
      broadcastUpdate({
        type: 'stock_updated',
        data: updatedStock
      });
      
      res.status(200).json(updatedStock);
    } catch (error) {
      console.error('Admin update stock error:', error);
      res.status(500).json({ message: 'Error updating stock' });
    }
  });
  
  app.delete('/api/admin/stocks/:id', isAdmin, async (req: Request, res: Response) => {
    try {
      const stockId = parseInt(req.params.id);
      
      if (isNaN(stockId)) {
        return res.status(400).json({ message: 'Invalid stock ID' });
      }
      
      const existingStock = await storage.getStock(stockId);
      
      if (!existingStock) {
        return res.status(404).json({ message: 'Stock not found' });
      }
      
      const result = await storage.deleteStock(stockId);
      
      if (!result) {
        return res.status(500).json({ message: 'Failed to delete stock' });
      }
      
      // Broadcast the update to all clients
      broadcastUpdate({
        type: 'stock_deleted',
        data: { id: stockId }
      });
      
      res.status(200).json({ message: 'Stock deleted successfully' });
    } catch (error) {
      console.error('Admin delete stock error:', error);
      res.status(500).json({ message: 'Error deleting stock' });
    }
  });

  return httpServer;
}
