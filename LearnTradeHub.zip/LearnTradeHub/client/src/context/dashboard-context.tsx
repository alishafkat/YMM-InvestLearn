import { createContext, useContext, useState, ReactNode } from "react";
import { create } from "zustand";

// Interface for the dashboard state
interface DashboardState {
  darkMode: boolean;
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}

// Create a Zustand store
export const useDashboard = create<DashboardState>((set) => ({
  darkMode: false,
  sidebarOpen: false,
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
}));

// Context for the dashboard
const DashboardContext = createContext<{
  darkMode: boolean;
  toggleDarkMode: () => void;
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
} | undefined>(undefined);

export function DashboardProvider({ children }: { children: ReactNode }) {
  const [darkMode, setDarkMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    useDashboard.setState({ darkMode: !darkMode });
  };

  const handleSetSidebarOpen = (open: boolean) => {
    setSidebarOpen(open);
    useDashboard.setState({ sidebarOpen: open });
  };

  const value = {
    darkMode,
    toggleDarkMode,
    sidebarOpen,
    setSidebarOpen: handleSetSidebarOpen,
  };

  return (
    <DashboardContext.Provider value={value}>
      {children}
    </DashboardContext.Provider>
  );
}

export function useDashboardContext() {
  const context = useContext(DashboardContext);
  if (context === undefined) {
    throw new Error('useDashboardContext must be used within a DashboardProvider');
  }
  return context;
}
