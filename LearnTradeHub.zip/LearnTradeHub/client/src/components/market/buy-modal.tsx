import { useState, useEffect } from "react";
import { useDashboard } from "@/context/dashboard-context";
import { Stock } from "@shared/schema";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface BuyModalProps {
  stock: Stock | null;
  isOpen: boolean;
  onClose: () => void;
  onBuy: (stockId: number, shares: number) => void;
  isBuying: boolean;
  userBalance: number;
}

export default function BuyModal({ 
  stock, 
  isOpen, 
  onClose, 
  onBuy, 
  isBuying,
  userBalance = 0 
}: BuyModalProps) {
  const { darkMode } = useDashboard();
  const [quantity, setQuantity] = useState(1);
  
  // Reset quantity when the modal opens
  useEffect(() => {
    if (isOpen) {
      setQuantity(1);
    }
  }, [isOpen, stock]);
  
  if (!stock) return null;

  // Calculate total cost
  const totalCost = quantity * Number(stock.price);
  
  // Check if user has sufficient balance
  const hasSufficientBalance = userBalance >= totalCost;
  
  // Format currency
  const formatCurrency = (value: number) => {
    return value.toLocaleString('en-US', { 
      style: 'currency',
      currency: 'USD'
    });
  };

  // Handle buy confirmation
  const handleBuy = () => {
    if (!stock || quantity <= 0 || !hasSufficientBalance) return;
    onBuy(stock.id, quantity);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Buy Stock</DialogTitle>
        </DialogHeader>

        <div className="mt-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <div className={`h-12 w-12 rounded-full ${darkMode ? 'bg-neutral-700' : 'bg-neutral-100'} flex items-center justify-center mr-4`}>
                <span className={`text-xl font-semibold ${darkMode ? 'text-white' : ''}`}>
                  {stock.symbol.charAt(0)}
                </span>
              </div>
              <div>
                <h4 className="text-lg font-semibold">{stock.symbol}</h4>
                <p className="text-sm text-neutral-500">{stock.name}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-lg font-mono font-semibold">{formatCurrency(Number(stock.price))}</p>
              <p className={`text-sm ${Number(stock.price) > Number(stock.previousPrice) ? 'text-accent' : 'text-danger'}`}>
                {Number(stock.price) > Number(stock.previousPrice) ? '+' : ''}
                {(((Number(stock.price) - Number(stock.previousPrice)) / Number(stock.previousPrice)) * 100).toFixed(1)}%
              </p>
            </div>
          </div>
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">Quantity</label>
            <div className="flex rounded-md shadow-sm">
              <button 
                className={`px-3 py-2 border border-r-0 rounded-l-md ${darkMode ? 'bg-neutral-700 border-neutral-600' : 'bg-neutral-100 border-neutral-300'}`}
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" />
                </svg>
              </button>
              <Input
                type="number"
                className="flex-1 min-w-0 block w-full px-3 py-2 text-center rounded-none"
                value={quantity}
                onChange={(e) => {
                  const value = parseInt(e.target.value);
                  if (!isNaN(value) && value > 0) {
                    setQuantity(value);
                  }
                }}
                min={1}
              />
              <button 
                className={`px-3 py-2 border border-l-0 rounded-r-md ${darkMode ? 'bg-neutral-700 border-neutral-600' : 'bg-neutral-100 border-neutral-300'}`}
                onClick={() => setQuantity(quantity + 1)}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
                </svg>
              </button>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">Cost</label>
              <div className="text-lg font-mono font-semibold">{formatCurrency(totalCost)}</div>
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">Available Funds</label>
              <div className="text-lg font-mono font-semibold">{formatCurrency(userBalance)}</div>
            </div>
          </div>
          
          {!hasSufficientBalance && (
            <div className="mb-4 p-3 bg-danger/10 border border-danger/20 rounded-md text-danger">
              <p className="text-sm">Insufficient balance to complete this purchase.</p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button 
            onClick={handleBuy} 
            disabled={isBuying || quantity <= 0 || !hasSufficientBalance}
          >
            {isBuying ? 'Processing...' : 'Confirm Purchase'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
