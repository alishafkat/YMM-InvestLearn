import { useDashboard } from "@/context/dashboard-context";
import { TransactionWithStock } from "@shared/schema";
import { format } from "date-fns";

interface RecentTransactionsProps {
  transactions: TransactionWithStock[];
  isLoading?: boolean;
}

export default function RecentTransactions({ transactions, isLoading }: RecentTransactionsProps) {
  const { darkMode } = useDashboard();
  
  if (isLoading) {
    return (
      <div className={`${darkMode ? 'bg-neutral-800' : 'bg-white'} rounded-lg shadow overflow-hidden`}>
        <div className={`px-6 py-5 border-b ${darkMode ? 'border-neutral-700' : 'border-neutral-200'}`}>
          <h3 className={`text-lg font-semibold ${darkMode ? 'text-white' : ''}`}>Recent Transactions</h3>
        </div>
        <div className="animate-pulse">
          {[...Array(3)].map((_, index) => (
            <div 
              key={index} 
              className={`px-6 py-4 flex justify-between items-center ${index !== 2 ? `border-b ${darkMode ? 'border-neutral-700' : 'border-neutral-200'}` : ''}`}
            >
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-neutral-200 dark:bg-neutral-700"></div>
                <div className="ml-4">
                  <div className="h-4 bg-neutral-200 dark:bg-neutral-700 rounded w-24 mb-2"></div>
                  <div className="h-3 bg-neutral-200 dark:bg-neutral-700 rounded w-32"></div>
                </div>
              </div>
              <div>
                <div className="h-4 bg-neutral-200 dark:bg-neutral-700 rounded w-16 mb-2"></div>
                <div className="h-3 bg-neutral-200 dark:bg-neutral-700 rounded w-24"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  const sortedTransactions = [...transactions].sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  ).slice(0, 5); // Take only the 5 most recent transactions

  return (
    <div className={`${darkMode ? 'bg-neutral-800' : 'bg-white'} rounded-lg shadow overflow-hidden`}>
      <div className={`px-6 py-5 border-b ${darkMode ? 'border-neutral-700' : 'border-neutral-200'}`}>
        <h3 className={`text-lg font-semibold ${darkMode ? 'text-white' : ''}`}>Recent Transactions</h3>
      </div>
      
      {sortedTransactions.length === 0 ? (
        <div className="px-6 py-4 text-center text-neutral-500">
          No transactions yet. Visit the Market to buy your first stock!
        </div>
      ) : (
        <div className={`divide-y ${darkMode ? 'divide-neutral-700' : 'divide-neutral-200'}`}>
          {sortedTransactions.map((transaction) => (
            <div key={transaction.id} className="px-6 py-4 flex justify-between items-center">
              <div className="flex items-center">
                <div 
                  className={`w-10 h-10 flex items-center justify-center rounded-full 
                    ${transaction.type === 'buy' 
                      ? 'bg-primary bg-opacity-10 text-primary' 
                      : 'bg-accent bg-opacity-10 text-accent'
                    }`}
                >
                  {transaction.type === 'buy' ? (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                    </svg>
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
                    </svg>
                  )}
                </div>
                <div className="ml-4">
                  <p className={`text-sm font-medium ${darkMode ? 'text-white' : ''}`}>
                    {transaction.type === 'buy' ? 'Bought' : 'Sold'} {transaction.stock.symbol}
                  </p>
                  <p className={`text-xs ${darkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>
                    {format(new Date(transaction.createdAt), 'MMM d, yyyy • h:mm a')}
                  </p>
                </div>
              </div>
              <div>
                <p className={`text-sm font-mono font-medium ${darkMode ? 'text-white' : ''}`}>
                  {transaction.type === 'buy' ? '-' : '+'}${Number(transaction.total).toFixed(2)}
                </p>
                <p className={`text-xs ${darkMode ? 'text-neutral-400' : 'text-neutral-500'} text-right`}>
                  {Number(transaction.shares).toFixed(2)} shares at ${Number(transaction.price).toFixed(2)}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
      
      {sortedTransactions.length > 0 && (
        <div className={`px-6 py-4 ${darkMode ? 'bg-neutral-900' : 'bg-neutral-50'}`}>
          <button className="text-primary text-sm font-medium">View all transactions</button>
        </div>
      )}
    </div>
  );
}
