import { useDashboard } from "@/context/dashboard-context";
import { UserWithPortfolio, PortfolioItemWithStock } from "@shared/schema";

interface MetricsGridProps {
  portfolioSummary: UserWithPortfolio;
}

export default function MetricsGrid({ portfolioSummary }: MetricsGridProps) {
  const { darkMode } = useDashboard();
  
  if (!portfolioSummary) return null;

  const { portfolioItems } = portfolioSummary;

  // Find top and worst performing stocks
  let topStock: PortfolioItemWithStock | null = null;
  let worstStock: PortfolioItemWithStock | null = null;

  if (portfolioItems.length > 0) {
    // Sort by gain/loss percentage
    const sortedItems = [...portfolioItems].sort((a, b) => 
      b.gainLossPercentage - a.gainLossPercentage
    );
    
    topStock = sortedItems[0];
    worstStock = sortedItems[sortedItems.length - 1];
  }

  // Calculate portfolio diversity (number of unique sectors)
  const sectors = new Set<string>();
  let sectorDistribution: Record<string, { count: number, percentage: number }> = {};
  
  portfolioItems.forEach(item => {
    const sector = item.stock.sector;
    sectors.add(sector);
    
    if (!sectorDistribution[sector]) {
      sectorDistribution[sector] = { count: 0, percentage: 0 };
    }
    
    sectorDistribution[sector].count += 1;
  });
  
  // Calculate sector percentages
  const totalItems = portfolioItems.length;
  Object.keys(sectorDistribution).forEach(sector => {
    sectorDistribution[sector].percentage = (sectorDistribution[sector].count / totalItems) * 100;
  });
  
  // Ordered sectors by percentage (descending)
  const orderedSectors = Object.entries(sectorDistribution)
    .sort(([, a], [, b]) => b.percentage - a.percentage)
    .map(([sector, data]) => ({ sector, ...data }));

  // Course progress (mock data for now, would come from LearnWorlds API)
  const completedModules = 6;
  const totalModules = 8;
  const progressPercentage = (completedModules / totalModules) * 100;

  // Colors for sector distribution
  const sectorColors = [
    "bg-blue-500",
    "bg-green-500",
    "bg-yellow-500", 
    "bg-purple-500",
    "bg-red-500",
    "bg-indigo-500",
    "bg-pink-500",
    "bg-teal-500"
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
      {/* Top performing stock */}
      <div className={`${darkMode ? 'bg-neutral-800' : 'bg-white'} rounded-lg shadow p-5`}>
        <div className="flex justify-between items-start">
          <div>
            <p className={`text-sm ${darkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>Top Performing</p>
            <h3 className={`text-lg font-semibold mt-1 ${darkMode ? 'text-white' : ''}`}>
              {topStock ? topStock.stock.symbol : 'No stocks'}
            </h3>
          </div>
          {topStock && (
            <div className="text-accent">
              <span className="text-lg font-semibold">
                +{topStock.gainLossPercentage.toFixed(1)}%
              </span>
            </div>
          )}
        </div>
        <div className="mt-3">
          <span className={`font-mono text-xl font-medium ${darkMode ? 'text-white' : ''}`}>
            {topStock ? `$${Number(topStock.stock.price).toFixed(2)}` : '-'}
          </span>
        </div>
      </div>
      
      {/* Worst performing stock */}
      <div className={`${darkMode ? 'bg-neutral-800' : 'bg-white'} rounded-lg shadow p-5`}>
        <div className="flex justify-between items-start">
          <div>
            <p className={`text-sm ${darkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>Worst Performing</p>
            <h3 className={`text-lg font-semibold mt-1 ${darkMode ? 'text-white' : ''}`}>
              {worstStock ? worstStock.stock.symbol : 'No stocks'}
            </h3>
          </div>
          {worstStock && (
            <div className={worstStock.gainLossPercentage >= 0 ? "text-accent" : "text-danger"}>
              <span className="text-lg font-semibold">
                {worstStock.gainLossPercentage >= 0 ? '+' : ''}{worstStock.gainLossPercentage.toFixed(1)}%
              </span>
            </div>
          )}
        </div>
        <div className="mt-3">
          <span className={`font-mono text-xl font-medium ${darkMode ? 'text-white' : ''}`}>
            {worstStock ? `$${Number(worstStock.stock.price).toFixed(2)}` : '-'}
          </span>
        </div>
      </div>
      
      {/* Portfolio Diversity */}
      <div className={`${darkMode ? 'bg-neutral-800' : 'bg-white'} rounded-lg shadow p-5`}>
        <div>
          <p className={`text-sm ${darkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>Portfolio Diversity</p>
          <h3 className={`text-lg font-semibold mt-1 ${darkMode ? 'text-white' : ''}`}>
            {sectors.size} Sectors
          </h3>
        </div>
        {orderedSectors.length > 0 ? (
          <>
            <div className="flex mt-3 space-x-1 h-2">
              {orderedSectors.map((sector, index) => (
                <div 
                  key={sector.sector}
                  className={`h-2 ${sectorColors[index % sectorColors.length]} ${index === 0 ? 'rounded-l' : ''} ${index === orderedSectors.length - 1 ? 'rounded-r' : ''}`}
                  style={{ width: `${sector.percentage}%` }}
                />
              ))}
            </div>
            <div className={`mt-2 text-xs ${darkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>
              {orderedSectors.map((sector, index) => (
                <span key={sector.sector}>
                  {sector.sector} ({sector.percentage.toFixed(0)}%)
                  {index < orderedSectors.length - 1 ? ' · ' : ''}
                </span>
              ))}
            </div>
          </>
        ) : (
          <div className="mt-3 text-sm text-neutral-500">No stocks in portfolio</div>
        )}
      </div>
      
      {/* Course Progress */}
      <div className={`${darkMode ? 'bg-neutral-800' : 'bg-white'} rounded-lg shadow p-5`}>
        <div>
          <p className={`text-sm ${darkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>Course Progress</p>
          <h3 className={`text-lg font-semibold mt-1 ${darkMode ? 'text-white' : ''}`}>Investment Fundamentals</h3>
        </div>
        <div className="mt-3">
          <div className={`w-full ${darkMode ? 'bg-neutral-700' : 'bg-neutral-200'} rounded-full h-2.5`}>
            <div 
              className="bg-primary h-2.5 rounded-full" 
              style={{ width: `${progressPercentage}%` }}
            />
          </div>
          <p className={`text-sm mt-2 ${darkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>
            <span className={`font-medium ${darkMode ? 'text-white' : 'text-neutral-800'}`}>
              {completedModules} of {totalModules}
            </span> modules completed
          </p>
        </div>
      </div>
    </div>
  );
}
