import { useDashboard } from "@/context/dashboard-context";
import { UserWithPortfolio } from "@shared/schema";

interface PortfolioSummaryProps {
  portfolioSummary: UserWithPortfolio;
}

export default function PortfolioSummary({ portfolioSummary }: PortfolioSummaryProps) {
  const { darkMode } = useDashboard();
  
  if (!portfolioSummary) return null;
  
  const { totalValue, totalGain } = portfolioSummary;
  const isPositiveGain = totalGain >= 0;
  const lastUpdated = new Date().toLocaleString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric',
    hour: 'numeric',
    minute: 'numeric',
    hour12: true
  });
  
  // Format percentages
  const formatPercentage = (value: number) => {
    return (value * 100).toFixed(1) + '%';
  };
  
  const gainPercentage = portfolioSummary.portfolioItems.length 
    ? formatPercentage(totalGain / (totalValue - totalGain))
    : '0.0%';

  return (
    <div className={`${darkMode ? 'bg-neutral-800' : 'bg-white'} rounded-lg shadow p-6 mb-6`}>
      <div className="flex flex-col md:flex-row justify-between mb-4">
        <div>
          <h2 className={`text-xl font-semibold mb-2 ${darkMode ? 'text-white' : ''}`}>Portfolio Summary</h2>
          <p className={`${darkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>Last updated: {lastUpdated}</p>
        </div>
        <div className="mt-4 md:mt-0">
          <div className="flex flex-col items-end">
            <div className={`text-3xl font-semibold font-mono ${darkMode ? 'text-white' : ''}`}>
              ${totalValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </div>
            <div className={`flex items-center ${isPositiveGain ? 'text-accent' : 'text-danger'}`}>
              {isPositiveGain ? (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M12 7a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0V8.414l-4.293 4.293a1 1 0 01-1.414 0L8 10.414l-4.293 4.293a1 1 0 01-1.414-1.414l5-5a1 1 0 011.414 0L11 10.586 14.586 7H12z" clipRule="evenodd" />
                </svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M12 13a1 1 0 100 2h5a1 1 0 001-1V9a1 1 0 10-2 0v2.586l-4.293-4.293a1 1 0 00-1.414 0L8 9.586 3.707 5.293a1 1 0 00-1.414 1.414l5 5a1 1 0 001.414 0L11 9.414 14.586 13H12z" clipRule="evenodd" />
                </svg>
              )}
              <span className="font-medium">
                {isPositiveGain ? '+' : ''}${Math.abs(totalGain).toLocaleString('en-US', { minimumFractionDigits: 2 })} ({isPositiveGain ? '+' : '-'}{gainPercentage})
              </span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Chart */}
      <div className="chart-container w-full mt-4 h-48">
        <svg className="w-full h-full" viewBox="0 0 400 200">
          {/* Chart Area */}
          <path 
            d="M0,200 L0,100 C20,80 40,110 60,90 C80,70 100,80 120,60 C140,40 160,60 180,40 C200,20 220,40 240,30 C260,20 280,50 300,40 C320,30 340,50 360,30 C380,10 400,30 400,20 L400,200 Z" 
            className="fill-primary/10"
          />
          {/* Chart Line */}
          <path 
            d="M0,100 C20,80 40,110 60,90 C80,70 100,80 120,60 C140,40 160,60 180,40 C200,20 220,40 240,30 C260,20 280,50 300,40 C320,30 340,50 360,30 C380,10 400,30 400,20" 
            className="fill-none stroke-primary stroke-2"
          />
          {/* Chart Points */}
          {[
            { cx: 0, cy: 100 },
            { cx: 60, cy: 90 },
            { cx: 120, cy: 60 },
            { cx: 180, cy: 40 },
            { cx: 240, cy: 30 },
            { cx: 300, cy: 40 },
            { cx: 360, cy: 30 },
            { cx: 400, cy: 20 }
          ].map((point, index) => (
            <circle 
              key={index}
              cx={point.cx} 
              cy={point.cy} 
              r="4" 
              className="fill-primary stroke-white stroke-2"
            />
          ))}
        </svg>
      </div>
    </div>
  );
}
