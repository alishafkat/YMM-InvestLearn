import { useDashboard } from "@/context/dashboard-context";
import { Stock } from "@shared/schema";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface StockManagementProps {
  stocks: Stock[];
  isLoading: boolean;
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  onEditClick: (stock: Stock) => void;
  onDeleteClick: (stockId: number) => void;
  isDeleting: boolean;
}

export default function StockManagement({ 
  stocks,
  isLoading,
  searchTerm,
  setSearchTerm,
  onEditClick,
  onDeleteClick,
  isDeleting
}: StockManagementProps) {
  const { darkMode } = useDashboard();
  
  // Format currency
  const formatCurrency = (value: number | string) => {
    return Number(value).toLocaleString('en-US', { 
      style: 'currency', 
      currency: 'USD' 
    });
  };
  
  // Calculate percentage change
  const calculateChange = (current: number | string, previous: number | string) => {
    if (!previous) return 0;
    
    const currentNum = Number(current);
    const previousNum = Number(previous);
    return ((currentNum - previousNum) / previousNum) * 100;
  };

  if (isLoading) {
    return (
      <div className={`${darkMode ? 'bg-neutral-800' : 'bg-white'} rounded-lg shadow overflow-hidden`}>
        <div className={`px-6 py-5 border-b ${darkMode ? 'border-neutral-700' : 'border-neutral-200'} flex justify-between items-center`}>
          <h3 className={`text-lg font-semibold ${darkMode ? 'text-white' : ''}`}>Manage Stocks</h3>
          <div className="relative">
            <Input
              type="text"
              placeholder="Search stocks..."
              className="pl-10 w-64"
              disabled
            />
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 absolute left-3 top-2.5 text-neutral-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
        </div>
        <div className="animate-pulse">
          {[...Array(3)].map((_, index) => (
            <div 
              key={index} 
              className={`px-6 py-4 flex justify-between items-center ${index !== 2 ? `border-b ${darkMode ? 'border-neutral-700' : 'border-neutral-200'}` : ''}`}
            >
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-neutral-200 dark:bg-neutral-700"></div>
                <div className="ml-4">
                  <div className="h-4 bg-neutral-200 dark:bg-neutral-700 rounded w-24 mb-2"></div>
                  <div className="h-3 bg-neutral-200 dark:bg-neutral-700 rounded w-32"></div>
                </div>
              </div>
              <div className="flex space-x-2">
                <div className="h-8 w-16 bg-neutral-200 dark:bg-neutral-700 rounded"></div>
                <div className="h-8 w-16 bg-neutral-200 dark:bg-neutral-700 rounded"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className={`${darkMode ? 'bg-neutral-800' : 'bg-white'} rounded-lg shadow overflow-hidden`}>
      <div className={`px-6 py-5 border-b ${darkMode ? 'border-neutral-700' : 'border-neutral-200'} flex justify-between items-center`}>
        <h3 className={`text-lg font-semibold ${darkMode ? 'text-white' : ''}`}>Manage Stocks</h3>
        <div className="relative">
          <Input
            type="text"
            placeholder="Search stocks..."
            className="pl-10 w-64"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 absolute left-3 top-2.5 text-neutral-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>
      </div>
      
      {stocks.length === 0 ? (
        <div className="px-6 py-12 text-center">
          <p className={`text-lg font-medium ${darkMode ? 'text-white' : ''}`}>
            {searchTerm ? 'No stocks found matching your search' : 'No stocks available'}
          </p>
          <p className="text-neutral-500 mt-2">
            {searchTerm ? 'Try a different search term' : 'Click "Add New Stock" to create one'}
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className={`min-w-full divide-y ${darkMode ? 'divide-neutral-700' : 'divide-neutral-200'}`}>
            <thead className={darkMode ? 'bg-neutral-900' : 'bg-neutral-50'}>
              <tr>
                <th scope="col" className={`px-6 py-3 text-left text-xs font-medium ${darkMode ? 'text-neutral-400' : 'text-neutral-500'} uppercase tracking-wider`}>
                  Stock
                </th>
                <th scope="col" className={`px-6 py-3 text-left text-xs font-medium ${darkMode ? 'text-neutral-400' : 'text-neutral-500'} uppercase tracking-wider`}>
                  Current Price
                </th>
                <th scope="col" className={`px-6 py-3 text-left text-xs font-medium ${darkMode ? 'text-neutral-400' : 'text-neutral-500'} uppercase tracking-wider`}>
                  Change
                </th>
                <th scope="col" className={`px-6 py-3 text-left text-xs font-medium ${darkMode ? 'text-neutral-400' : 'text-neutral-500'} uppercase tracking-wider`}>
                  Investors
                </th>
                <th scope="col" className={`px-6 py-3 text-left text-xs font-medium ${darkMode ? 'text-neutral-400' : 'text-neutral-500'} uppercase tracking-wider`}>
                  Status
                </th>
                <th scope="col" className={`px-6 py-3 text-right text-xs font-medium ${darkMode ? 'text-neutral-400' : 'text-neutral-500'} uppercase tracking-wider`}>
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className={`${darkMode ? 'bg-neutral-800' : 'bg-white'} divide-y ${darkMode ? 'divide-neutral-700' : 'divide-neutral-200'}`}>
              {stocks.map((stock) => {
                const changePercentage = calculateChange(stock.price, stock.previousPrice);
                const isIncreasing = changePercentage >= 0;
                
                return (
                  <tr key={stock.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className={`flex-shrink-0 h-10 w-10 rounded-full ${darkMode ? 'bg-neutral-700' : 'bg-neutral-100'} flex items-center justify-center`}>
                          <span className={`text-lg font-semibold ${darkMode ? 'text-white' : ''}`}>
                            {stock.symbol.charAt(0)}
                          </span>
                        </div>
                        <div className="ml-4">
                          <div className={`text-sm font-medium ${darkMode ? 'text-white' : ''}`}>
                            {stock.symbol}
                          </div>
                          <div className={`text-sm ${darkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>
                            {stock.name}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className={`text-sm font-mono font-medium ${darkMode ? 'text-white' : ''}`}>
                        {formatCurrency(stock.price)}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        isIncreasing 
                          ? 'bg-accent bg-opacity-10 text-accent' 
                          : 'bg-danger bg-opacity-10 text-danger'
                      }`}>
                        {isIncreasing ? (
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M12 7a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0V8.414l-4.293 4.293a1 1 0 01-1.414 0L8 10.414l-4.293 4.293a1 1 0 01-1.414-1.414l5-5a1 1 0 011.414 0L11 10.586 14.586 7H12z" clipRule="evenodd" />
                          </svg>
                        ) : (
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M12 13a1 1 0 100 2h5a1 1 0 001-1V9a1 1 0 10-2 0v2.586l-4.293-4.293a1 1 0 00-1.414 0L8 9.586 3.707 5.293a1 1 0 00-1.414 1.414l5 5a1 1 0 001.414 0L11 9.414 14.586 13H12z" clipRule="evenodd" />
                          </svg>
                        )}
                        <span>{isIncreasing ? '+' : ''}{changePercentage.toFixed(1)}%</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className={`text-sm ${darkMode ? 'text-white' : ''}`}>
                        {Math.floor(Math.random() * 50) + 1}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        stock.isActive 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-neutral-100 text-neutral-800'
                      }`}>
                        {stock.isActive ? 'Active' : 'Inactive'}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button 
                        className="text-primary hover:text-primary/80 mr-3"
                        onClick={() => onEditClick(stock)}
                      >
                        Edit
                      </button>
                      <button 
                        className="text-danger hover:text-danger/80"
                        onClick={() => onDeleteClick(stock.id)}
                        disabled={isDeleting}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
      
      {stocks.length > 0 && (
        <div className={`px-6 py-4 ${darkMode ? 'bg-neutral-900' : 'bg-neutral-50'} flex items-center justify-between`}>
          <div className={`text-sm ${darkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>
            Showing <span className={`font-medium ${darkMode ? 'text-white' : ''}`}>1</span> to <span className={`font-medium ${darkMode ? 'text-white' : ''}`}>{stocks.length}</span> of <span className={`font-medium ${darkMode ? 'text-white' : ''}`}>{stocks.length}</span> results
          </div>
          <div className="flex space-x-2">
            <button 
              className={`px-3 py-1 border rounded-md text-sm ${
                darkMode 
                  ? 'border-neutral-600 text-white' 
                  : 'border-neutral-300'
              }`}
              disabled
            >
              Previous
            </button>
            <button 
              className={`px-3 py-1 border rounded-md text-sm bg-primary text-white ${
                darkMode ? 'border-primary' : ''
              }`}
            >
              1
            </button>
            <button 
              className={`px-3 py-1 border rounded-md text-sm ${
                darkMode 
                  ? 'border-neutral-600 text-white' 
                  : 'border-neutral-300'
              }`}
              disabled
            >
              Next
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
