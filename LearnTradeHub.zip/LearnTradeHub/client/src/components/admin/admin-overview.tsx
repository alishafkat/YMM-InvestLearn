import { useDashboard } from "@/context/dashboard-context";

interface AdminOverviewProps {
  stocksCount: number;
  onAddStockClick: () => void;
}

export default function AdminOverview({ stocksCount, onAddStockClick }: AdminOverviewProps) {
  const { darkMode } = useDashboard();

  return (
    <div className={`${darkMode ? 'bg-neutral-800' : 'bg-white'} rounded-lg shadow p-6 mb-6`}>
      <div className="flex flex-col md:flex-row justify-between mb-4">
        <div>
          <h2 className={`text-xl font-semibold mb-2 ${darkMode ? 'text-white' : ''}`}>Admin Dashboard</h2>
          <p className={`${darkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>Manage stocks and view platform statistics</p>
        </div>
        <div className="mt-4 md:mt-0">
          <button 
            onClick={onAddStockClick}
            className="bg-primary text-white px-4 py-2 rounded-md flex items-center hover:bg-primary/90"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
            </svg>
            Add New Stock
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
        <div className={`p-4 border rounded-lg ${darkMode ? 'border-neutral-700' : 'border-neutral-200'}`}>
          <div className="flex justify-between items-start">
            <div>
              <p className={`text-sm ${darkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>Total Users</p>
              <p className={`text-2xl font-semibold mt-1 ${darkMode ? 'text-white' : ''}`}>152</p>
            </div>
            <div className="bg-blue-500 bg-opacity-10 text-blue-500 p-2 rounded-full">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
              </svg>
            </div>
          </div>
        </div>
        <div className={`p-4 border rounded-lg ${darkMode ? 'border-neutral-700' : 'border-neutral-200'}`}>
          <div className="flex justify-between items-start">
            <div>
              <p className={`text-sm ${darkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>Total Investments</p>
              <p className={`text-2xl font-mono font-semibold mt-1 ${darkMode ? 'text-white' : ''}`}>$1,254,890</p>
            </div>
            <div className="bg-accent bg-opacity-10 text-accent p-2 rounded-full">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z" />
              </svg>
            </div>
          </div>
        </div>
        <div className={`p-4 border rounded-lg ${darkMode ? 'border-neutral-700' : 'border-neutral-200'}`}>
          <div className="flex justify-between items-start">
            <div>
              <p className={`text-sm ${darkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>Active Stocks</p>
              <p className={`text-2xl font-semibold mt-1 ${darkMode ? 'text-white' : ''}`}>{stocksCount}</p>
            </div>
            <div className="bg-primary bg-opacity-10 text-primary p-2 rounded-full">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
