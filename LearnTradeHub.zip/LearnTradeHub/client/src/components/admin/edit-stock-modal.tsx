import { useEffect } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useDashboard } from "@/context/dashboard-context";
import { Stock, insertStockSchema } from "@shared/schema";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

interface EditStockModalProps {
  stock: Stock | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: any) => void;
  isSubmitting: boolean;
}

export default function EditStockModal({ 
  stock, 
  isOpen, 
  onClose, 
  onSave,
  isSubmitting 
}: EditStockModalProps) {
  const { darkMode } = useDashboard();
  
  // Define sectors
  const sectors = [
    "Technology", 
    "Consumer Cyclical", 
    "Financial Services", 
    "Communication Services", 
    "Healthcare", 
    "Energy", 
    "Industrials", 
    "Basic Materials", 
    "Utilities", 
    "Real Estate",
    "Consumer Defensive"
  ];

  // Setup form with validation
  const form = useForm({
    resolver: zodResolver(insertStockSchema.extend({
      price: insertStockSchema.shape.price,
      marketCap: insertStockSchema.shape.marketCap
    })),
    defaultValues: {
      symbol: stock?.symbol || '',
      name: stock?.name || '',
      price: stock?.price?.toString() || '',
      sector: stock?.sector || sectors[0],
      marketCap: stock?.marketCap || '',
      isActive: stock?.isActive !== undefined ? stock.isActive : true,
    }
  });

  // Update form values when stock changes
  useEffect(() => {
    if (stock) {
      form.reset({
        symbol: stock.symbol || '',
        name: stock.name || '',
        price: stock.price?.toString() || '',
        sector: stock.sector || sectors[0],
        marketCap: stock.marketCap || '',
        isActive: stock.isActive !== undefined ? stock.isActive : true,
      });
    } else {
      form.reset({
        symbol: '',
        name: '',
        price: '',
        sector: sectors[0],
        marketCap: '',
        isActive: true,
      });
    }
  }, [stock, form, sectors]);

  // Handle form submission
  const onSubmit = (data: any) => {
    // Convert string values to proper types
    data.price = parseFloat(data.price);
    data.isActive = data.isActive === true || data.isActive === "true";
    
    // Save the stock
    onSave(data);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{stock ? 'Edit Stock' : 'Add New Stock'}</DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="symbol"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Symbol</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="AAPL" 
                      {...field} 
                      disabled={!!stock} // Don't allow editing the symbol for existing stocks
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Company Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Apple Inc." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="price"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Current Price ($)</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      step="0.01" 
                      placeholder="182.63" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="sector"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Sector</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                    value={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a sector" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {sectors.map((sector) => (
                        <SelectItem key={sector} value={sector}>
                          {sector}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="marketCap"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Market Cap</FormLabel>
                  <FormControl>
                    <Input placeholder="2.8T" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="isActive"
              render={({ field }) => (
                <FormItem className="space-y-3">
                  <FormLabel>Status</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={(value) => field.onChange(value === "true")}
                      defaultValue={field.value ? "true" : "false"}
                      value={field.value ? "true" : "false"}
                      className="flex space-x-4"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="true" id="active" />
                        <Label htmlFor="active">Active</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="false" id="inactive" />
                        <Label htmlFor="inactive">Inactive</Label>
                      </div>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter className="mt-6">
              <Button 
                variant="outline" 
                onClick={onClose}
                type="button"
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Saving...' : (stock ? 'Save Changes' : 'Add Stock')}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
