import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useDashboard } from "@/context/dashboard-context";
import { PortfolioItemWithStock } from "@shared/schema";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface PortfolioHoldingsProps {
  portfolioItems: PortfolioItemWithStock[];
}

export default function PortfolioHoldings({ portfolioItems }: PortfolioHoldingsProps) {
  const { darkMode } = useDashboard();
  const [selectedItem, setSelectedItem] = useState<PortfolioItemWithStock | null>(null);
  const [isSellModalOpen, setIsSellModalOpen] = useState(false);
  const [sharesToSell, setSharesToSell] = useState<number>(0);
  
  // Sort portfolio items by value (descending)
  const sortedItems = [...portfolioItems].sort((a, b) => b.value - a.value);

  // Sell stock mutation
  const { mutate: sellStock, isPending: isSelling } = useMutation({
    mutationFn: async ({ stockId, shares }: { stockId: number; shares: number }) => {
      const res = await apiRequest('POST', '/api/stocks/sell', { stockId, shares });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/portfolio'] });
      queryClient.invalidateQueries({ queryKey: ['/api/portfolio/summary'] });
      queryClient.invalidateQueries({ queryKey: ['/api/transactions'] });
      queryClient.invalidateQueries({ queryKey: ['/api/auth/session'] });
      setIsSellModalOpen(false);
      setSharesToSell(0);
    },
  });

  // Handle sell button click
  const handleSellClick = (item: PortfolioItemWithStock) => {
    setSelectedItem(item);
    setSharesToSell(Number(item.shares));
    setIsSellModalOpen(true);
  };

  // Handle sell confirmation
  const handleSellConfirm = () => {
    if (!selectedItem || sharesToSell <= 0 || sharesToSell > Number(selectedItem.shares)) return;
    
    sellStock({
      stockId: selectedItem.stockId,
      shares: sharesToSell
    });
  };

  // Format currency
  const formatCurrency = (value: number) => {
    return value.toLocaleString('en-US', { 
      style: 'currency', 
      currency: 'USD',
      minimumFractionDigits: 2
    });
  };

  return (
    <>
      <div className={`${darkMode ? 'bg-neutral-800' : 'bg-white'} rounded-lg shadow overflow-hidden`}>
        <div className={`px-6 py-5 border-b ${darkMode ? 'border-neutral-700' : 'border-neutral-200'}`}>
          <h3 className={`text-lg font-semibold ${darkMode ? 'text-white' : ''}`}>Portfolio Holdings</h3>
        </div>
        
        {sortedItems.length === 0 ? (
          <div className="px-6 py-12 text-center">
            <div className="mx-auto w-24 h-24 rounded-full bg-neutral-100 dark:bg-neutral-700 flex items-center justify-center mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-neutral-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h4 className={`text-lg font-medium mb-2 ${darkMode ? 'text-white' : 'text-neutral-800'}`}>
              No Stocks in Portfolio
            </h4>
            <p className="text-neutral-500 max-w-md mx-auto mb-6">
              You haven't purchased any stocks yet. Visit the Market to start investing your virtual money!
            </p>
            <Button 
              className="bg-primary hover:bg-primary/90"
              onClick={() => window.location.href = '/market'}
            >
              Go to Market
            </Button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className={`min-w-full divide-y ${darkMode ? 'divide-neutral-700' : 'divide-neutral-200'}`}>
              <thead className={darkMode ? 'bg-neutral-900' : 'bg-neutral-50'}>
                <tr>
                  <th scope="col" className={`px-6 py-3 text-left text-xs font-medium ${darkMode ? 'text-neutral-400' : 'text-neutral-500'} uppercase tracking-wider`}>
                    Stock
                  </th>
                  <th scope="col" className={`px-6 py-3 text-left text-xs font-medium ${darkMode ? 'text-neutral-400' : 'text-neutral-500'} uppercase tracking-wider`}>
                    Shares
                  </th>
                  <th scope="col" className={`px-6 py-3 text-left text-xs font-medium ${darkMode ? 'text-neutral-400' : 'text-neutral-500'} uppercase tracking-wider`}>
                    Avg. Price
                  </th>
                  <th scope="col" className={`px-6 py-3 text-left text-xs font-medium ${darkMode ? 'text-neutral-400' : 'text-neutral-500'} uppercase tracking-wider`}>
                    Current Price
                  </th>
                  <th scope="col" className={`px-6 py-3 text-left text-xs font-medium ${darkMode ? 'text-neutral-400' : 'text-neutral-500'} uppercase tracking-wider`}>
                    Value
                  </th>
                  <th scope="col" className={`px-6 py-3 text-left text-xs font-medium ${darkMode ? 'text-neutral-400' : 'text-neutral-500'} uppercase tracking-wider`}>
                    Gain/Loss
                  </th>
                  <th scope="col" className={`px-6 py-3 text-right text-xs font-medium ${darkMode ? 'text-neutral-400' : 'text-neutral-500'} uppercase tracking-wider`}>
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className={`${darkMode ? 'bg-neutral-800' : 'bg-white'} divide-y ${darkMode ? 'divide-neutral-700' : 'divide-neutral-200'}`}>
                {sortedItems.map((item) => (
                  <tr key={item.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className={`flex-shrink-0 h-10 w-10 rounded-full ${darkMode ? 'bg-neutral-700' : 'bg-neutral-100'} flex items-center justify-center`}>
                          <span className={`text-lg font-semibold ${darkMode ? 'text-white' : ''}`}>
                            {item.stock.symbol.charAt(0)}
                          </span>
                        </div>
                        <div className="ml-4">
                          <div className={`text-sm font-medium ${darkMode ? 'text-white' : ''}`}>
                            {item.stock.symbol}
                          </div>
                          <div className={`text-sm ${darkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>
                            {item.stock.name}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className={`text-sm ${darkMode ? 'text-white' : ''}`}>
                        {Number(item.shares).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className={`text-sm font-mono ${darkMode ? 'text-white' : ''}`}>
                        {formatCurrency(Number(item.avgPrice))}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className={`text-sm font-mono ${darkMode ? 'text-white' : ''}`}>
                        {formatCurrency(Number(item.stock.price))}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className={`text-sm font-mono ${darkMode ? 'text-white' : ''}`}>
                        {formatCurrency(item.value)}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className={`text-sm font-mono ${item.gainLoss >= 0 ? 'text-accent' : 'text-danger'}`}>
                        {item.gainLoss >= 0 ? '+' : ''}{formatCurrency(item.gainLoss)} ({item.gainLossPercentage >= 0 ? '+' : ''}{item.gainLossPercentage.toFixed(1)}%)
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button 
                        className="text-primary hover:text-primary/80"
                        onClick={() => handleSellClick(item)}
                      >
                        Sell
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Sell Modal */}
      <Dialog open={isSellModalOpen} onOpenChange={setIsSellModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Sell Stock</DialogTitle>
            <DialogDescription>
              Enter the number of shares you want to sell
            </DialogDescription>
          </DialogHeader>

          {selectedItem && (
            <div className="space-y-4 py-2">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <div className={`h-12 w-12 rounded-full ${darkMode ? 'bg-neutral-700' : 'bg-neutral-100'} flex items-center justify-center mr-4`}>
                    <span className={`text-xl font-semibold ${darkMode ? 'text-white' : ''}`}>
                      {selectedItem.stock.symbol.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold">{selectedItem.stock.symbol}</h4>
                    <p className="text-sm text-neutral-500">{selectedItem.stock.name}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-lg font-mono font-semibold">
                    {formatCurrency(Number(selectedItem.stock.price))}
                  </p>
                  <p className={`text-sm ${Number(selectedItem.stock.price) > Number(selectedItem.stock.previousPrice) ? 'text-accent' : 'text-danger'}`}>
                    {Number(selectedItem.stock.price) > Number(selectedItem.stock.previousPrice) ? '+' : ''}
                    {(((Number(selectedItem.stock.price) - Number(selectedItem.stock.previousPrice)) / Number(selectedItem.stock.previousPrice)) * 100).toFixed(1)}%
                  </p>
                </div>
              </div>
              
              <div className="mb-4">
                <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                  Quantity (max: {Number(selectedItem.shares).toLocaleString()})
                </label>
                <div className="flex rounded-md shadow-sm">
                  <button 
                    className={`px-3 py-2 border border-r-0 rounded-l-md ${darkMode ? 'bg-neutral-700 border-neutral-600' : 'bg-neutral-100 border-neutral-300'}`}
                    onClick={() => setSharesToSell(Math.max(1, Math.min(sharesToSell - 1, Number(selectedItem.shares))))}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" />
                    </svg>
                  </button>
                  <Input
                    type="number"
                    className="flex-1 min-w-0 block w-full px-3 py-2 text-center rounded-none"
                    value={sharesToSell}
                    onChange={(e) => {
                      const value = parseFloat(e.target.value);
                      if (isNaN(value)) {
                        setSharesToSell(0);
                      } else {
                        setSharesToSell(Math.min(value, Number(selectedItem.shares)));
                      }
                    }}
                    min={0}
                    max={Number(selectedItem.shares)}
                    step={1}
                  />
                  <button 
                    className={`px-3 py-2 border border-l-0 rounded-r-md ${darkMode ? 'bg-neutral-700 border-neutral-600' : 'bg-neutral-100 border-neutral-300'}`}
                    onClick={() => setSharesToSell(Math.min(sharesToSell + 1, Number(selectedItem.shares)))}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
                    </svg>
                  </button>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                    Sale Value
                  </label>
                  <div className="text-lg font-mono font-semibold">
                    {formatCurrency(sharesToSell * Number(selectedItem.stock.price))}
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                    Profit/Loss
                  </label>
                  <div className={`text-lg font-mono font-semibold ${
                    (sharesToSell * Number(selectedItem.stock.price)) - (sharesToSell * Number(selectedItem.avgPrice)) >= 0 
                      ? 'text-accent' 
                      : 'text-danger'
                  }`}>
                    {formatCurrency((sharesToSell * Number(selectedItem.stock.price)) - (sharesToSell * Number(selectedItem.avgPrice)))}
                  </div>
                </div>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsSellModalOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleSellConfirm} 
              disabled={isSelling || sharesToSell <= 0 || (selectedItem && sharesToSell > Number(selectedItem.shares))}
            >
              {isSelling ? 'Selling...' : 'Confirm Sale'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
