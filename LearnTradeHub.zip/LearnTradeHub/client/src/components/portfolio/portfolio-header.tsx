import { useDashboard } from "@/context/dashboard-context";
import { UserWithPortfolio } from "@shared/schema";

interface PortfolioHeaderProps {
  portfolioSummary: UserWithPortfolio;
}

export default function PortfolioHeader({ portfolioSummary }: PortfolioHeaderProps) {
  const { darkMode } = useDashboard();
  
  if (!portfolioSummary) return null;

  const { totalValue, totalGain, portfolioItems } = portfolioSummary;
  
  // Calculate today's change (simplified: using total gain as today's change)
  const todayChange = totalGain;
  
  // Generate data for allocation chart
  type SectorAllocation = {
    sector: string;
    value: number;
    percentage: number;
    color: string;
    offset: number;
  };
  
  const colors = [
    "#3366FF", // primary
    "#10B981", // accent
    "#EF4444", // danger
    "#F59E0B", // amber
    "#8B5CF6", // purple
    "#EC4899", // pink
    "#06B6D4", // cyan
    "#84CC16"  // lime
  ];
  
  const sectorTotals: Record<string, number> = {};
  
  // Calculate total value by sector
  portfolioItems.forEach(item => {
    const sector = item.stock.sector;
    const value = Number(item.shares) * Number(item.stock.price);
    
    if (!sectorTotals[sector]) {
      sectorTotals[sector] = 0;
    }
    
    sectorTotals[sector] += value;
  });
  
  // Create allocation data
  const sectorAllocations: SectorAllocation[] = Object.entries(sectorTotals)
    .map(([sector, value], index) => ({
      sector,
      value,
      percentage: (value / totalValue) * 100,
      color: colors[index % colors.length],
      offset: 0 // Will calculate next
    }));
  
  // Calculate stroke-dashoffset for each sector
  let currentOffset = 0;
  sectorAllocations.forEach(allocation => {
    allocation.offset = currentOffset;
    currentOffset -= allocation.percentage;
  });

  return (
    <div className={`${darkMode ? 'bg-neutral-800' : 'bg-white'} rounded-lg shadow p-6 mb-6`}>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <h2 className={`text-xl font-semibold mb-2 ${darkMode ? 'text-white' : ''}`}>Your Portfolio</h2>
          <p className={`${darkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>Current value and performance</p>
          
          <div className="mt-4 grid grid-cols-2 gap-4">
            <div>
              <p className={`text-sm ${darkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>Total Value</p>
              <p className={`text-2xl font-mono font-semibold ${darkMode ? 'text-white' : ''}`}>
                ${totalValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </p>
            </div>
            <div>
              <p className={`text-sm ${darkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>Total Gain/Loss</p>
              <p className={`text-2xl font-mono font-semibold ${totalGain >= 0 ? 'text-accent' : 'text-danger'}`}>
                {totalGain >= 0 ? '+' : ''}${totalGain.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </p>
            </div>
            <div>
              <p className={`text-sm ${darkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>Stocks Owned</p>
              <p className={`text-2xl font-semibold ${darkMode ? 'text-white' : ''}`}>
                {portfolioItems.length}
              </p>
            </div>
            <div>
              <p className={`text-sm ${darkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>Today's Change</p>
              <p className={`text-2xl font-mono font-semibold ${todayChange >= 0 ? 'text-accent' : 'text-danger'}`}>
                {todayChange >= 0 ? '+' : ''}${todayChange.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </p>
            </div>
          </div>
        </div>
        <div className="flex justify-center">
          <div className="w-48 h-48 relative">
            {portfolioItems.length > 0 ? (
              <svg className="w-full h-full" viewBox="0 0 36 36">
                <circle cx="18" cy="18" r="15.9155" fill="none" stroke={darkMode ? "#374151" : "#E5E7EB"} strokeWidth="3" />
                
                {sectorAllocations.map((allocation, index) => (
                  <path 
                    key={allocation.sector}
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" 
                    fill="none" 
                    stroke={allocation.color} 
                    strokeWidth="3" 
                    strokeDasharray={`${allocation.percentage}, 100`} 
                    strokeDashoffset={allocation.offset}
                  />
                ))}
                
                <text x="18" y="14" textAnchor="middle" className={`text-xs font-semibold ${darkMode ? 'fill-white' : 'fill-neutral-800'}`}>
                  Allocation
                </text>
                <text x="18" y="22" textAnchor="middle" className={`text-xs ${darkMode ? 'fill-neutral-400' : 'fill-neutral-500'}`}>
                  by Sector
                </text>
              </svg>
            ) : (
              <div className={`w-full h-full rounded-full border-2 ${darkMode ? 'border-neutral-700' : 'border-neutral-200'} flex items-center justify-center`}>
                <p className="text-center text-sm text-neutral-500">No stocks in portfolio</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
