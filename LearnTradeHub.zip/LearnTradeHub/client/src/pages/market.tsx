import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useAuth } from "@/context/auth-context";
import { useDashboard } from "@/context/dashboard-context";
import { queryClient, apiRequest } from "@/lib/queryClient";
import Sidebar from "@/components/layout/sidebar";
import MobileSidebar from "@/components/layout/mobile-sidebar";
import StockListings from "@/components/market/stock-listings";
import BuyModal from "@/components/market/buy-modal";
import { Stock } from "@shared/schema";

export default function Market() {
  const [location, navigate] = useLocation();
  const { user, isLoading: isLoadingAuth } = useAuth();
  const { darkMode, sidebarOpen, setSidebarOpen } = useDashboard();
  
  const [selectedStock, setSelectedStock] = useState<Stock | null>(null);
  const [isBuyModalOpen, setIsBuyModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  // Fetch stocks
  const { data: stocks, isLoading: isLoadingStocks } = useQuery({
    queryKey: ['/api/stocks'],
    enabled: !!user,
  });

  // Buy stock mutation
  const { mutate: buyStock, isPending: isBuying } = useMutation({
    mutationFn: async ({ stockId, shares }: { stockId: number; shares: number }) => {
      const res = await apiRequest('POST', '/api/stocks/buy', { stockId, shares });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/portfolio'] });
      queryClient.invalidateQueries({ queryKey: ['/api/portfolio/summary'] });
      queryClient.invalidateQueries({ queryKey: ['/api/transactions'] });
      queryClient.invalidateQueries({ queryKey: ['/api/auth/session'] });
      setIsBuyModalOpen(false);
    },
  });

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoadingAuth && !user) {
      navigate('/login');
    }
  }, [user, isLoadingAuth, navigate]);

  if (isLoadingAuth || !user) {
    return <div>Loading...</div>;
  }

  // Filter stocks based on search term
  const filteredStocks = stocks?.filter(stock => 
    stock.symbol.toLowerCase().includes(searchTerm.toLowerCase()) || 
    stock.name.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  return (
    <div className={`flex h-screen overflow-hidden ${darkMode ? 'bg-neutral-900 text-white' : ''}`}>
      <Sidebar />
      <MobileSidebar open={sidebarOpen} setOpen={setSidebarOpen} />
      
      {/* Mobile sidebar toggle */}
      <div className="md:hidden fixed bottom-4 right-4 z-10">
        <button 
          onClick={() => setSidebarOpen(!sidebarOpen)} 
          className="rounded-full bg-primary text-white p-3 shadow-lg"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>

      {/* Main content area */}
      <div className="flex flex-col w-0 flex-1 overflow-hidden">
        <main className="flex-1 relative overflow-y-auto focus:outline-none">
          <div className="py-6">
            {/* Top Header */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 flex justify-between items-center">
              <div>
                <h1 className={`text-2xl font-semibold ${darkMode ? 'text-white' : 'text-neutral-900'}`}>
                  Market
                </h1>
              </div>
              <div className="flex items-center space-x-4">
                <div className={`${darkMode ? 'bg-neutral-800' : 'bg-white'} shadow rounded-lg px-3 py-2 flex items-center`}>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-yellow-500 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M8.433 7.418c.155-.103.346-.196.567-.267v1.698a2.305 2.305 0 01-.567-.267C8.07 8.34 8 8.114 8 8c0-.114.07-.34.433-.582zM11 12.849v-1.698c.22.071.412.164.567.267.364.243.433.468.433.582 0 .114-.07.34-.433.582a2.305 2.305 0 01-.567.267z" />
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-13a1 1 0 10-2 0v.092a4.535 4.535 0 00-1.676.662C6.602 6.234 6 7.009 6 8c0 .99.602 1.765 1.324 2.246.48.32 1.054.545 1.676.662v1.941c-.391-.127-.68-.317-.843-.504a1 1 0 10-1.51 1.31c.562.649 1.413 1.076 2.353 1.253V15a1 1 0 102 0v-.092a4.535 4.535 0 001.676-.662C13.398 13.766 14 12.991 14 12c0-.99-.602-1.765-1.324-2.246A4.535 4.535 0 0011 9.092V7.151c.391.127.68.317.843.504a1 1 0 101.511-1.31c-.563-.649-1.413-1.076-2.354-1.253V5z" clipRule="evenodd" />
                  </svg>
                  <span className="text-lg font-mono font-medium">
                    ${user?.balance?.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </span>
                </div>
                <button 
                  onClick={() => useDashboard.setState({ darkMode: !darkMode })}
                  className={`rounded-full p-2 ${darkMode ? 'hover:bg-neutral-700' : 'hover:bg-neutral-200'}`}
                >
                  {darkMode ? (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z" clipRule="evenodd" />
                    </svg>
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-neutral-600" viewBox="0 0 20 20" fill="currentColor">
                      <path d="M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z" />
                    </svg>
                  )}
                </button>
              </div>
            </div>

            {/* Market Content */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 mt-6">
              {/* Market Overview */}
              <div className={`${darkMode ? 'bg-neutral-800' : 'bg-white'} rounded-lg shadow p-6 mb-6`}>
                <h2 className={`text-xl font-semibold mb-4 ${darkMode ? 'text-white' : ''}`}>Market Overview</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className={`p-4 border ${darkMode ? 'border-neutral-700' : 'border-neutral-200'} rounded-lg`}>
                    <div className="flex justify-between items-start">
                      <div>
                        <p className={`text-sm ${darkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>Available Balance</p>
                        <p className={`text-2xl font-mono font-semibold mt-1 ${darkMode ? 'text-white' : ''}`}>
                          ${user?.balance?.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                        </p>
                      </div>
                      <div className="bg-primary bg-opacity-10 text-primary p-2 rounded-full">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
                        </svg>
                      </div>
                    </div>
                  </div>
                  <div className={`p-4 border ${darkMode ? 'border-neutral-700' : 'border-neutral-200'} rounded-lg`}>
                    <div className="flex justify-between items-start">
                      <div>
                        <p className={`text-sm ${darkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>Market Trend</p>
                        <p className="text-2xl font-semibold mt-1 text-secondary">
                          {stocks && stocks.filter(s => Number(s.price) > Number(s.previousPrice)).length > stocks?.length / 2 
                            ? 'Bullish' 
                            : 'Bearish'}
                        </p>
                      </div>
                      <div className="bg-secondary text-white p-2 rounded-full">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                        </svg>
                      </div>
                    </div>
                  </div>
                  <div className={`p-4 border ${darkMode ? 'border-neutral-700' : 'border-neutral-200'} rounded-lg`}>
                    <div className="flex justify-between items-start">
                      <div>
                        <p className={`text-sm ${darkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>Available Stocks</p>
                        <p className={`text-2xl font-semibold mt-1 ${darkMode ? 'text-white' : ''}`}>
                          {stocks?.length || 0}
                        </p>
                      </div>
                      <div className="bg-primary bg-opacity-10 text-primary p-2 rounded-full">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Stock Listings */}
              <StockListings 
                stocks={filteredStocks} 
                isLoading={isLoadingStocks}
                searchTerm={searchTerm}
                setSearchTerm={setSearchTerm}
                onBuyClick={(stock) => {
                  setSelectedStock(stock);
                  setIsBuyModalOpen(true);
                }}
              />
              
              {/* Buy Modal */}
              <BuyModal 
                stock={selectedStock}
                isOpen={isBuyModalOpen}
                onClose={() => setIsBuyModalOpen(false)}
                onBuy={(stockId, shares) => buyStock({ stockId, shares })}
                isBuying={isBuying}
                userBalance={user?.balance}
              />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
