import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useAuth } from "@/context/auth-context";
import { useDashboard } from "@/context/dashboard-context";
import Sidebar from "@/components/layout/sidebar";
import MobileSidebar from "@/components/layout/mobile-sidebar";
import PortfolioHeader from "@/components/portfolio/portfolio-header";
import PortfolioHoldings from "@/components/portfolio/portfolio-holdings";

export default function Portfolio() {
  const [location, navigate] = useLocation();
  const { user, isLoading: isLoadingAuth } = useAuth();
  const { darkMode, sidebarOpen, setSidebarOpen } = useDashboard();

  // Fetch portfolio summary
  const { data: portfolioSummary, isLoading: isLoadingSummary } = useQuery({
    queryKey: ['/api/portfolio/summary'],
    enabled: !!user,
  });

  // Fetch portfolio items
  const { data: portfolioItems, isLoading: isLoadingPortfolio } = useQuery({
    queryKey: ['/api/portfolio'],
    enabled: !!user,
  });

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoadingAuth && !user) {
      navigate('/login');
    }
  }, [user, isLoadingAuth, navigate]);

  if (isLoadingAuth || !user) {
    return <div>Loading...</div>;
  }

  return (
    <div className={`flex h-screen overflow-hidden ${darkMode ? 'bg-neutral-900 text-white' : ''}`}>
      <Sidebar />
      <MobileSidebar open={sidebarOpen} setOpen={setSidebarOpen} />
      
      {/* Mobile sidebar toggle */}
      <div className="md:hidden fixed bottom-4 right-4 z-10">
        <button 
          onClick={() => setSidebarOpen(!sidebarOpen)} 
          className="rounded-full bg-primary text-white p-3 shadow-lg"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>

      {/* Main content area */}
      <div className="flex flex-col w-0 flex-1 overflow-hidden">
        <main className="flex-1 relative overflow-y-auto focus:outline-none">
          <div className="py-6">
            {/* Top Header */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 flex justify-between items-center">
              <div>
                <h1 className={`text-2xl font-semibold ${darkMode ? 'text-white' : 'text-neutral-900'}`}>
                  Portfolio
                </h1>
              </div>
              <div className="flex items-center space-x-4">
                <div className={`${darkMode ? 'bg-neutral-800' : 'bg-white'} shadow rounded-lg px-3 py-2 flex items-center`}>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-yellow-500 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M8.433 7.418c.155-.103.346-.196.567-.267v1.698a2.305 2.305 0 01-.567-.267C8.07 8.34 8 8.114 8 8c0-.114.07-.34.433-.582zM11 12.849v-1.698c.22.071.412.164.567.267.364.243.433.468.433.582 0 .114-.07.34-.433.582a2.305 2.305 0 01-.567.267z" />
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-13a1 1 0 10-2 0v.092a4.535 4.535 0 00-1.676.662C6.602 6.234 6 7.009 6 8c0 .99.602 1.765 1.324 2.246.48.32 1.054.545 1.676.662v1.941c-.391-.127-.68-.317-.843-.504a1 1 0 10-1.51 1.31c.562.649 1.413 1.076 2.353 1.253V15a1 1 0 102 0v-.092a4.535 4.535 0 001.676-.662C13.398 13.766 14 12.991 14 12c0-.99-.602-1.765-1.324-2.246A4.535 4.535 0 0011 9.092V7.151c.391.127.68.317.843.504a1 1 0 101.511-1.31c-.563-.649-1.413-1.076-2.354-1.253V5z" clipRule="evenodd" />
                  </svg>
                  <span className="text-lg font-mono font-medium">
                    ${user?.balance?.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </span>
                </div>
                <button 
                  onClick={() => useDashboard.setState({ darkMode: !darkMode })}
                  className={`rounded-full p-2 ${darkMode ? 'hover:bg-neutral-700' : 'hover:bg-neutral-200'}`}
                >
                  {darkMode ? (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z" clipRule="evenodd" />
                    </svg>
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-neutral-600" viewBox="0 0 20 20" fill="currentColor">
                      <path d="M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z" />
                    </svg>
                  )}
                </button>
              </div>
            </div>

            {/* Portfolio Content */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 mt-6">
              {isLoadingSummary || isLoadingPortfolio ? (
                <div className="animate-pulse space-y-6">
                  <div className={`${darkMode ? 'bg-neutral-800' : 'bg-white'} rounded-lg shadow p-6 h-64`}></div>
                  <div className={`${darkMode ? 'bg-neutral-800' : 'bg-white'} rounded-lg shadow overflow-hidden h-96`}></div>
                </div>
              ) : (
                <>
                  <PortfolioHeader 
                    portfolioSummary={portfolioSummary} 
                  />
                  <PortfolioHoldings 
                    portfolioItems={portfolioItems || []} 
                  />
                </>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
