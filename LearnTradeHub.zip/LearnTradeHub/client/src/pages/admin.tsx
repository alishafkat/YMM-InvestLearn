import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useAuth } from "@/context/auth-context";
import { useDashboard } from "@/context/dashboard-context";
import { queryClient, apiRequest } from "@/lib/queryClient";
import Sidebar from "@/components/layout/sidebar";
import MobileSidebar from "@/components/layout/mobile-sidebar";
import AdminOverview from "@/components/admin/admin-overview";
import StockManagement from "@/components/admin/stock-management";
import EditStockModal from "@/components/admin/edit-stock-modal";
import { Stock, InsertStock } from "@shared/schema";

export default function Admin() {
  const [location, navigate] = useLocation();
  const { user, isLoading: isLoadingAuth } = useAuth();
  const { darkMode, sidebarOpen, setSidebarOpen } = useDashboard();
  
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedStock, setSelectedStock] = useState<Stock | null>(null);
  const [searchTerm, setSearchTerm] = useState("");

  // Fetch stocks (including inactive ones for admin)
  const { data: stocks, isLoading: isLoadingStocks } = useQuery({
    queryKey: ['/api/admin/stocks'],
    enabled: !!user?.isAdmin,
  });

  // Create stock mutation
  const { mutate: createStock, isPending: isCreating } = useMutation({
    mutationFn: async (stock: InsertStock) => {
      const res = await apiRequest('POST', '/api/admin/stocks', stock);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/stocks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stocks'] });
      setIsEditModalOpen(false);
    },
  });

  // Update stock mutation
  const { mutate: updateStock, isPending: isUpdating } = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertStock> }) => {
      const res = await apiRequest('PUT', `/api/admin/stocks/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/stocks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stocks'] });
      setIsEditModalOpen(false);
    },
  });

  // Delete stock mutation
  const { mutate: deleteStock, isPending: isDeleting } = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest('DELETE', `/api/admin/stocks/${id}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/stocks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stocks'] });
    },
  });

  // Redirect if not authenticated or not admin
  useEffect(() => {
    if (!isLoadingAuth && (!user || !user.isAdmin)) {
      navigate('/');
    }
  }, [user, isLoadingAuth, navigate]);

  if (isLoadingAuth || !user || !user.isAdmin) {
    return <div>Loading...</div>;
  }

  // Filter stocks based on search term
  const filteredStocks = stocks?.filter(stock => 
    stock.symbol.toLowerCase().includes(searchTerm.toLowerCase()) || 
    stock.name.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  return (
    <div className={`flex h-screen overflow-hidden ${darkMode ? 'bg-neutral-900 text-white' : ''}`}>
      <Sidebar />
      <MobileSidebar open={sidebarOpen} setOpen={setSidebarOpen} />
      
      {/* Mobile sidebar toggle */}
      <div className="md:hidden fixed bottom-4 right-4 z-10">
        <button 
          onClick={() => setSidebarOpen(!sidebarOpen)} 
          className="rounded-full bg-primary text-white p-3 shadow-lg"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>

      {/* Main content area */}
      <div className="flex flex-col w-0 flex-1 overflow-hidden">
        <main className="flex-1 relative overflow-y-auto focus:outline-none">
          <div className="py-6">
            {/* Top Header */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 flex justify-between items-center">
              <div>
                <h1 className={`text-2xl font-semibold ${darkMode ? 'text-white' : 'text-neutral-900'}`}>
                  Admin Panel
                </h1>
              </div>
              <div className="flex items-center space-x-4">
                <button 
                  onClick={() => useDashboard.setState({ darkMode: !darkMode })}
                  className={`rounded-full p-2 ${darkMode ? 'hover:bg-neutral-700' : 'hover:bg-neutral-200'}`}
                >
                  {darkMode ? (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z" clipRule="evenodd" />
                    </svg>
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-neutral-600" viewBox="0 0 20 20" fill="currentColor">
                      <path d="M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z" />
                    </svg>
                  )}
                </button>
              </div>
            </div>

            {/* Admin Content */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 mt-6">
              <AdminOverview 
                stocksCount={stocks?.length || 0}
                onAddStockClick={() => {
                  setSelectedStock(null);
                  setIsEditModalOpen(true);
                }}
              />
              
              <StockManagement 
                stocks={filteredStocks}
                isLoading={isLoadingStocks}
                searchTerm={searchTerm}
                setSearchTerm={setSearchTerm}
                onEditClick={(stock) => {
                  setSelectedStock(stock);
                  setIsEditModalOpen(true);
                }}
                onDeleteClick={(stockId) => {
                  if (window.confirm('Are you sure you want to delete this stock?')) {
                    deleteStock(stockId);
                  }
                }}
                isDeleting={isDeleting}
              />
              
              <EditStockModal 
                stock={selectedStock}
                isOpen={isEditModalOpen}
                onClose={() => setIsEditModalOpen(false)}
                onSave={(data) => {
                  if (selectedStock) {
                    updateStock({ id: selectedStock.id, data });
                  } else {
                    createStock(data);
                  }
                }}
                isSubmitting={isCreating || isUpdating}
              />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
