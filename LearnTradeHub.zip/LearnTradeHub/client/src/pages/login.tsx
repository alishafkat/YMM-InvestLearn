import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useMutation } from '@tanstack/react-query';
import { useAuth } from '@/context/auth-context';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { apiRequest } from '@/lib/queryClient';

export default function Login() {
  const [location, navigate] = useLocation();
  const { user, isLoading: isLoadingAuth, login } = useAuth();
  
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  // Redirect if already authenticated
  useEffect(() => {
    if (!isLoadingAuth && user) {
      navigate('/');
    }
  }, [user, isLoadingAuth, navigate]);

  // LearnWorlds login mutation (simulation since we don't have actual LearnWorlds API)
  const { mutate: learnWorldsLogin, isPending: isLWLoggingIn } = useMutation({
    mutationFn: async () => {
      // In a real implementation, this would redirect to LearnWorlds OAuth
      // For demo purposes, we'll simulate a successful login
      const mockLearnWorldsData = {
        learnWorldsId: 'lw_' + Math.random().toString(36).substring(2, 9),
        email: 'user@example.com',
        name: 'Demo User'
      };
      
      const res = await apiRequest('POST', '/api/auth/learnworlds-login', mockLearnWorldsData);
      return res.json();
    },
    onSuccess: (data) => {
      login(data);
      navigate('/');
    },
    onError: (error) => {
      setError('Failed to login with LearnWorlds');
      console.error(error);
    }
  });

  // Direct login mutation
  const { mutate: directLogin, isPending: isDirectLoggingIn } = useMutation({
    mutationFn: async ({ username, password }: { username: string; password: string }) => {
      const res = await apiRequest('POST', '/api/auth/login', { username, password });
      return res.json();
    },
    onSuccess: (data) => {
      login(data);
      navigate('/');
    },
    onError: (error) => {
      setError('Invalid username or password');
      console.error(error);
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      setError('Username and password are required');
      return;
    }
    
    directLogin({ username, password });
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-bold text-center">InvestLearn</CardTitle>
          <CardDescription className="text-center">
            Log in to access your virtual investment portfolio
          </CardDescription>
        </CardHeader>
        <CardContent>
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input 
                id="username" 
                type="text" 
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter your username"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input 
                id="password" 
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
              />
            </div>
            <Button 
              type="submit" 
              className="w-full" 
              disabled={isDirectLoggingIn}
            >
              {isDirectLoggingIn ? 'Logging in...' : 'Login'}
            </Button>
          </form>
          
          <div className="relative my-4">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-300"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-gray-500">or</span>
            </div>
          </div>
          
          <Button
            variant="outline"
            className="w-full"
            onClick={() => learnWorldsLogin()}
            disabled={isLWLoggingIn}
          >
            {isLWLoggingIn ? 'Connecting...' : 'Login with LearnWorlds'}
          </Button>
        </CardContent>
        <CardFooter className="flex flex-col space-y-2">
          <p className="text-xs text-center text-gray-500">
            For demo purposes, you can use any username/password. <br />
            The LearnWorlds integration is simulated.
          </p>
        </CardFooter>
      </Card>
    </div>
  );
}
