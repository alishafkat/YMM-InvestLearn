// Helper functions for chart generation

/**
 * Generates SVG path for area chart
 * @param data Array of data points
 * @param width Chart width
 * @param height Chart height
 * @param padding Padding inside the chart
 * @returns Path data strings for the area and line
 */
export function generateAreaChartPaths(
  data: number[], 
  width: number = 400, 
  height: number = 200, 
  padding: number = 10
): { areaPath: string; linePath: string; points: {x: number, y: number}[] } {
  if (data.length === 0) {
    return { areaPath: '', linePath: '', points: [] };
  }
  
  const chartWidth = width - (padding * 2);
  const chartHeight = height - (padding * 2);
  
  // Find min and max values
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min > 0 ? max - min : 1;
  
  // Calculate x and y positions
  const points = data.map((value, index) => {
    const x = padding + (index / (data.length - 1)) * chartWidth;
    const y = padding + chartHeight - ((value - min) / range) * chartHeight;
    return { x, y };
  });
  
  // Generate line path
  let linePath = `M${points[0].x},${points[0].y}`;
  for (let i = 1; i < points.length; i++) {
    const cpx1 = points[i - 1].x + (points[i].x - points[i - 1].x) / 3;
    const cpy1 = points[i - 1].y;
    const cpx2 = points[i].x - (points[i].x - points[i - 1].x) / 3;
    const cpy2 = points[i].y;
    linePath += ` C${cpx1},${cpy1} ${cpx2},${cpy2} ${points[i].x},${points[i].y}`;
  }
  
  // Generate area path (line + bottom border + close)
  const areaPath = `${linePath} L${points[points.length - 1].x},${height - padding} L${points[0].x},${height - padding} Z`;
  
  return { areaPath, linePath, points };
}

/**
 * Generates simple sparkline path
 * @param data Array of data points
 * @param width Chart width
 * @param height Chart height
 * @returns Path data string for the sparkline
 */
export function generateSparklinePath(
  data: number[], 
  width: number = 100, 
  height: number = 30
): string {
  if (data.length === 0) {
    return '';
  }
  
  // Find min and max values
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min > 0 ? max - min : 1;
  
  // Calculate x and y positions
  const points = data.map((value, index) => {
    const x = (index / (data.length - 1)) * width;
    const y = height - ((value - min) / range) * height;
    return { x, y };
  });
  
  // Generate path
  let path = `M${points[0].x},${points[0].y}`;
  for (let i = 1; i < points.length; i++) {
    path += ` L${points[i].x},${points[i].y}`;
  }
  
  return path;
}

/**
 * Generates data for a pie/donut chart
 * @param data Object with labels and values
 * @returns Array of segment data with start and end angles
 */
export function generatePieChartData(
  data: Record<string, number>
): Array<{ label: string; value: number; percentage: number; startAngle: number; endAngle: number }> {
  const total = Object.values(data).reduce((sum, value) => sum + value, 0);
  
  if (total === 0) {
    return [];
  }
  
  let currentAngle = 0;
  
  return Object.entries(data).map(([label, value]) => {
    const percentage = (value / total) * 100;
    const angle = (value / total) * 360;
    const startAngle = currentAngle;
    const endAngle = currentAngle + angle;
    currentAngle = endAngle;
    
    return {
      label,
      value,
      percentage,
      startAngle,
      endAngle
    };
  });
}

/**
 * Converts polar coordinates to cartesian
 * @param centerX Center X position
 * @param centerY Center Y position
 * @param radius Radius
 * @param angleInDegrees Angle in degrees
 * @returns X and Y coordinates
 */
export function polarToCartesian(
  centerX: number, 
  centerY: number, 
  radius: number, 
  angleInDegrees: number
): { x: number; y: number } {
  const angleInRadians = (angleInDegrees - 90) * Math.PI / 180.0;
  
  return {
    x: centerX + (radius * Math.cos(angleInRadians)),
    y: centerY + (radius * Math.sin(angleInRadians))
  };
}

/**
 * Generates SVG path for an arc (for pie/donut charts)
 * @param x Center X position
 * @param y Center Y position
 * @param radius Radius
 * @param startAngle Start angle in degrees
 * @param endAngle End angle in degrees
 * @returns Path data string for the arc
 */
export function describeArc(
  x: number, 
  y: number, 
  radius: number, 
  startAngle: number, 
  endAngle: number
): string {
  const start = polarToCartesian(x, y, radius, endAngle);
  const end = polarToCartesian(x, y, radius, startAngle);
  
  const largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1";
  
  return [
    "M", start.x, start.y, 
    "A", radius, radius, 0, largeArcFlag, 0, end.x, end.y,
    "L", x, y,
    "Z"
  ].join(" ");
}
