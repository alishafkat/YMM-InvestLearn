import { apiRequest } from "./queryClient";
import { Stock, User, PortfolioItemWithStock, TransactionWithStock } from "@shared/schema";

// Authentication
export async function login(username: string, password: string): Promise<User> {
  const res = await apiRequest('POST', '/api/auth/login', { username, password });
  return res.json();
}

export async function learnWorldsLogin(learnWorldsId: string, email?: string, name?: string): Promise<User> {
  const res = await apiRequest('POST', '/api/auth/learnworlds-login', { learnWorldsId, email, name });
  return res.json();
}

export async function logout(): Promise<void> {
  await apiRequest('GET', '/api/auth/logout');
}

export async function getSession(): Promise<User | null> {
  try {
    const res = await apiRequest('GET', '/api/auth/session');
    return res.json();
  } catch (error) {
    return null;
  }
}

// User
export async function getUserProfile(): Promise<User> {
  const res = await apiRequest('GET', '/api/user/profile');
  return res.json();
}

export async function rewardUser(moduleId: string, moduleName: string, rewardAmount: number): Promise<User> {
  const res = await apiRequest('POST', '/api/user/reward', { moduleId, moduleName, rewardAmount });
  return res.json();
}

// Stocks
export async function getStocks(): Promise<Stock[]> {
  const res = await apiRequest('GET', '/api/stocks');
  return res.json();
}

export async function getStock(id: number): Promise<Stock> {
  const res = await apiRequest('GET', `/api/stocks/${id}`);
  return res.json();
}

export async function buyStock(stockId: number, shares: number): Promise<any> {
  const res = await apiRequest('POST', '/api/stocks/buy', { stockId, shares });
  return res.json();
}

export async function sellStock(stockId: number, shares: number): Promise<any> {
  const res = await apiRequest('POST', '/api/stocks/sell', { stockId, shares });
  return res.json();
}

// Portfolio
export async function getPortfolio(): Promise<PortfolioItemWithStock[]> {
  const res = await apiRequest('GET', '/api/portfolio');
  return res.json();
}

export async function getPortfolioSummary(): Promise<any> {
  const res = await apiRequest('GET', '/api/portfolio/summary');
  return res.json();
}

// Transactions
export async function getTransactions(): Promise<TransactionWithStock[]> {
  const res = await apiRequest('GET', '/api/transactions');
  return res.json();
}

// Admin routes
export async function getAdminStocks(): Promise<Stock[]> {
  const res = await apiRequest('GET', '/api/admin/stocks');
  return res.json();
}

export async function createStock(stock: any): Promise<Stock> {
  const res = await apiRequest('POST', '/api/admin/stocks', stock);
  return res.json();
}

export async function updateStock(id: number, stock: any): Promise<Stock> {
  const res = await apiRequest('PUT', `/api/admin/stocks/${id}`, stock);
  return res.json();
}

export async function deleteStock(id: number): Promise<void> {
  await apiRequest('DELETE', `/api/admin/stocks/${id}`);
}
