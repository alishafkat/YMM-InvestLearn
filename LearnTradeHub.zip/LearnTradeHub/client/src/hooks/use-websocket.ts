import { useState, useEffect, useRef, useCallback } from 'react';

export type WebSocketMessage = {
  type: string;
  data?: any;
  message?: string;
};

export interface UseWebSocketOptions {
  onOpen?: (event: WebSocketEventMap['open']) => void;
  onMessage?: (message: WebSocketMessage) => void;
  onError?: (event: WebSocketEventMap['error']) => void;
  onClose?: (event: WebSocketEventMap['close']) => void;
  reconnectInterval?: number;
  reconnectAttempts?: number;
  shouldReconnect?: boolean;
}

export function useWebSocket(
  options: UseWebSocketOptions = {}
) {
  const [isConnected, setIsConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<WebSocketMessage | null>(null);
  const socketRef = useRef<WebSocket | null>(null);
  const reconnectCount = useRef(0);
  const reconnectTimerRef = useRef<number | null>(null);

  const {
    onOpen,
    onMessage,
    onError,
    onClose,
    reconnectInterval = 3000,
    reconnectAttempts = 5,
    shouldReconnect = true,
  } = options;

  const connect = useCallback(() => {
    // Close existing connection if any
    if (socketRef.current) {
      socketRef.current.close();
    }

    // Create WebSocket connection
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const socket = new WebSocket(wsUrl);
    socketRef.current = socket;

    socket.onopen = (event) => {
      console.log('WebSocket connected');
      setIsConnected(true);
      reconnectCount.current = 0;
      if (onOpen) onOpen(event);
    };

    socket.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data) as WebSocketMessage;
        setLastMessage(message);
        if (onMessage) onMessage(message);
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };

    socket.onerror = (event) => {
      console.error('WebSocket error:', event);
      if (onError) onError(event);
    };

    socket.onclose = (event) => {
      console.log('WebSocket disconnected');
      setIsConnected(false);
      
      if (onClose) onClose(event);
      
      // Attempt to reconnect if enabled and not closed manually
      if (shouldReconnect && reconnectCount.current < reconnectAttempts) {
        reconnectCount.current += 1;
        console.log(`Attempting to reconnect (${reconnectCount.current}/${reconnectAttempts})...`);
        
        if (reconnectTimerRef.current) {
          window.clearTimeout(reconnectTimerRef.current);
        }
        
        reconnectTimerRef.current = window.setTimeout(() => {
          connect();
        }, reconnectInterval);
      }
    };
  }, [onOpen, onMessage, onError, onClose, reconnectInterval, reconnectAttempts, shouldReconnect]);

  // Send message function
  const sendMessage = useCallback((message: string | object) => {
    if (!socketRef.current || socketRef.current.readyState !== WebSocket.OPEN) {
      console.error('WebSocket is not connected');
      return false;
    }
    
    const messageToSend = typeof message === 'string' 
      ? message 
      : JSON.stringify(message);
      
    socketRef.current.send(messageToSend);
    return true;
  }, []);

  // Disconnect function
  const disconnect = useCallback(() => {
    if (reconnectTimerRef.current) {
      window.clearTimeout(reconnectTimerRef.current);
      reconnectTimerRef.current = null;
    }
    
    if (socketRef.current) {
      socketRef.current.close();
      socketRef.current = null;
    }
  }, []);

  // Connect on mount, disconnect on unmount
  useEffect(() => {
    connect();
    
    return () => {
      disconnect();
    };
  }, [connect, disconnect]);

  return {
    isConnected,
    lastMessage,
    sendMessage,
    connect,
    disconnect
  };
}
