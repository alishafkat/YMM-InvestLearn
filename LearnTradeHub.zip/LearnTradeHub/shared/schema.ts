import { pgTable, text, serial, integer, boolean, numeric, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  learnWorldsId: text("learnworlds_id"),
  email: text("email"),
  name: text("name"),
  balance: numeric("balance", { precision: 10, scale: 2 }).default("10000").notNull(),
  avatar: text("avatar"),
  isAdmin: boolean("is_admin").default(false).notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  learnWorldsId: true,
  email: true,
  name: true,
  avatar: true,
  isAdmin: true,
  balance: true,
});

// Stock schema
export const stocks = pgTable("stocks", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull().unique(),
  name: text("name").notNull(),
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  previousPrice: numeric("previous_price", { precision: 10, scale: 2 }),
  sector: text("sector").notNull(),
  marketCap: text("market_cap"),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertStockSchema = createInsertSchema(stocks).pick({
  symbol: true,
  name: true,
  price: true,
  previousPrice: true,
  sector: true,
  marketCap: true,
  isActive: true,
});

// Portfolio (User's stock holdings)
export const portfolioItems = pgTable("portfolio_items", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  stockId: integer("stock_id").notNull().references(() => stocks.id),
  shares: numeric("shares", { precision: 10, scale: 2 }).notNull(),
  avgPrice: numeric("avg_price", { precision: 10, scale: 2 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertPortfolioItemSchema = createInsertSchema(portfolioItems).pick({
  userId: true,
  stockId: true,
  shares: true,
  avgPrice: true,
});

// Transactions
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  stockId: integer("stock_id").notNull().references(() => stocks.id),
  type: text("type").notNull(), // 'buy' or 'sell'
  shares: numeric("shares", { precision: 10, scale: 2 }).notNull(),
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  total: numeric("total", { precision: 10, scale: 2 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTransactionSchema = createInsertSchema(transactions).pick({
  userId: true,
  stockId: true,
  type: true,
  shares: true,
  price: true,
  total: true,
});

// Module Completion
export const moduleCompletions = pgTable("module_completions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  moduleId: text("module_id").notNull(),
  moduleName: text("module_name").notNull(),
  completedAt: timestamp("completed_at").defaultNow().notNull(),
  rewardAmount: numeric("reward_amount", { precision: 10, scale: 2 }),
});

export const insertModuleCompletionSchema = createInsertSchema(moduleCompletions).pick({
  userId: true,
  moduleId: true,
  moduleName: true,
  rewardAmount: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Stock = typeof stocks.$inferSelect;
export type InsertStock = z.infer<typeof insertStockSchema>;

export type PortfolioItem = typeof portfolioItems.$inferSelect;
export type InsertPortfolioItem = z.infer<typeof insertPortfolioItemSchema>;

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

export type ModuleCompletion = typeof moduleCompletions.$inferSelect;
export type InsertModuleCompletion = z.infer<typeof insertModuleCompletionSchema>;

// Additional types for frontend
export interface PortfolioItemWithStock extends PortfolioItem {
  stock: Stock;
  value: number;
  gainLoss: number;
  gainLossPercentage: number;
}

export interface TransactionWithStock extends Transaction {
  stock: Stock;
}

export interface UserWithPortfolio extends User {
  portfolioItems: PortfolioItemWithStock[];
  totalValue: number;
  totalGain: number;
}
